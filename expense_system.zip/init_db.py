from app import create_app
from models import db, User, Department, ExpenseCategory
from werkzeug.security import generate_password_hash


def init_database():
    app = create_app()

    with app.app_context():
        db.drop_all()
        db.create_all()

        departments = [
            Department(name='技术部'),
            Department(name='市场部'),
            Department(name='财务部'),
            Department(name='人事部'),
        ]
        db.session.add_all(departments)
        db.session.flush()

        users = [
            User(
                username='admin',
                password_hash=generate_password_hash('admin123'),
                real_name='管理员',
                role='admin'
            ),
            User(
                username='zhangsan',
                password_hash=generate_password_hash('123456'),
                real_name='张三',
                department_id=departments[0].id,
                role='employee'
            ),
            User(
                username='lisi',
                password_hash=generate_password_hash('123456'),
                real_name='李四',
                department_id=departments[0].id,
                role='manager'
            ),
            User(
                username='wangwu',
                password_hash=generate_password_hash('123456'),
                real_name='王五',
                department_id=departments[2].id,
                role='finance'
            ),
        ]
        db.session.add_all(users)

        departments[0].manager_id = users[2].id

        categories = [
            ExpenseCategory(name='交通费', code='JC01', description='市内交通、打车等费用'),
            ExpenseCategory(name='餐饮费', code='CY01', description='工作餐、商务宴请等费用'),
            ExpenseCategory(name='办公用品', code='BG01', description='笔墨纸张、办公设备耗材等'),
            ExpenseCategory(name='通讯费', code='TX01', description='电话费、网络费等'),
            ExpenseCategory(name='差旅费', code='CL01', description='出差交通、住宿等费用'),
        ]
        db.session.add_all(categories)

        db.session.commit()
        print('数据库初始化成功!')
        print('=' * 50)
        print('管理员账号: admin / admin123')
        print('=' * 50)
        print('测试账号:')
        print('  技术部 - 员工: zhangsan / 123456')
        print('  技术部 - 经理: lisi / 123456')
        print('  财务部 - 财务: wangwu / 123456')
        print('=' * 50)


if __name__ == '__main__':
    init_database()
