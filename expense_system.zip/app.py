from flask import Flask
from config import Config
from models import db
from auth import auth_bp, login_manager
from views import main_bp
from reimbursement import reimbursement_bp
from approval import approval_bp
from statistics import statistics_bp
from notifications import register_notifications


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    login_manager.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(main_bp)
    app.register_blueprint(reimbursement_bp)
    app.register_blueprint(approval_bp)
    app.register_blueprint(statistics_bp)

    register_notifications(app)

    with app.app_context():
        db.create_all()

    return app


app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
