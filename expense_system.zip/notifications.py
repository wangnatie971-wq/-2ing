from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models import db, ReimbursementRequest
from sqlalchemy import func

notifications_bp = Blueprint('notifications', __name__)


@login_required
def get_pending_notifications():
    if current_user.role == 'manager':
        count = ReimbursementRequest.query.filter_by(status='pending').join(
            ReimbursementRequest.applicant
        ).filter_by(department_id=current_user.department_id).count()
        requests = ReimbursementRequest.query.filter_by(status='pending').join(
            ReimbursementRequest.applicant
        ).filter_by(department_id=current_user.department_id).order_by(
            ReimbursementRequest.created_at.desc()
        ).limit(5).all()
    elif current_user.role == 'finance':
        count = ReimbursementRequest.query.filter_by(status='dept_approved').count()
        requests = ReimbursementRequest.query.filter_by(status='dept_approved').order_by(
            ReimbursementRequest.dept_approved_at.desc()
        ).limit(5).all()
    elif current_user.role == 'admin':
        pending_count = ReimbursementRequest.query.filter_by(status='pending').count()
        dept_approved_count = ReimbursementRequest.query.filter_by(status='dept_approved').count()
        count = pending_count + dept_approved_count
        requests = ReimbursementRequest.query.filter(
            ReimbursementRequest.status.in_(['pending', 'dept_approved'])
        ).order_by(ReimbursementRequest.created_at.desc()).limit(5).all()
    else:
        count = 0
        requests = []

    return {'count': count, 'requests': requests}


def register_notifications(app):
    @app.context_processor
    def inject_notifications():
        if current_user.is_authenticated:
            notifications = get_pending_notifications()
            return dict(pending_notifications=notifications)
        return dict(pending_notifications={'count': 0, 'requests': []})
