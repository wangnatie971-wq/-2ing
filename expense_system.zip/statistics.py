from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models import db, ReimbursementRequest, ReimbursementItem, Department, ExpenseCategory
from sqlalchemy import func
from datetime import datetime
from calendar import monthrange

statistics_bp = Blueprint('statistics', __name__, url_prefix='/statistics')


@statistics_bp.route('/')
@login_required
def index():
    if current_user.role not in ['manager', 'finance', 'admin']:
        return render_template('errors/403.html'), 403

    now = datetime.utcnow()
    _, last_day = monthrange(now.year, now.month)
    month_start = datetime(now.year, now.month, 1)
    month_end = datetime(now.year, now.month, last_day, 23, 59, 59)

    monthly_total = db.session.query(
        func.coalesce(func.sum(ReimbursementRequest.total_amount), 0)
    ).filter(
        ReimbursementRequest.status == 'approved',
        ReimbursementRequest.finance_approved_at >= month_start,
        ReimbursementRequest.finance_approved_at <= month_end
    ).scalar()

    pending_count = ReimbursementRequest.query.filter(
        ReimbursementRequest.status.in_(['pending', 'dept_approved'])
    ).count()

    completed_count = ReimbursementRequest.query.filter_by(status='approved').count()

    dept_data = db.session.query(
        Department.name,
        func.coalesce(func.sum(ReimbursementRequest.total_amount), 0)
    ).join(ReimbursementRequest, ReimbursementRequest.applicant_id == Department.id
    ).filter(
        ReimbursementRequest.status == 'approved'
    ).group_by(Department.id, Department.name).all()

    dept_labels = [d[0] for d in dept_data]
    dept_amounts = [float(d[1]) for d in dept_data]

    category_data = db.session.query(
        ExpenseCategory.name,
        func.coalesce(func.sum(ReimbursementItem.amount), 0)
    ).join(ReimbursementItem, ReimbursementItem.category_id == ExpenseCategory.id
    ).join(ReimbursementRequest, ReimbursementRequest.id == ReimbursementItem.request_id
    ).filter(
        ReimbursementRequest.status == 'approved'
    ).group_by(ExpenseCategory.id, ExpenseCategory.name).all()

    category_labels = [c[0] for c in category_data]
    category_amounts = [float(c[1]) for c in category_data]

    stats = {
        'monthly_total': float(monthly_total),
        'pending_count': pending_count,
        'completed_count': completed_count
    }

    return render_template('statistics/index.html',
                         stats=stats,
                         dept_labels=dept_labels,
                         dept_amounts=dept_amounts,
                         category_labels=category_labels,
                         category_amounts=category_amounts)
