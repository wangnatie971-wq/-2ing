from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin

db = SQLAlchemy()


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    real_name = db.Column(db.String(100), nullable=False)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'))
    role = db.Column(db.String(20), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    department = db.relationship('Department', back_populates='users')
    reimbursement_requests = db.relationship('ReimbursementRequest', foreign_keys='ReimbursementRequest.applicant_id', back_populates='applicant')
    dept_approved_requests = db.relationship('ReimbursementRequest', foreign_keys='ReimbursementRequest.dept_approver_id', back_populates='dept_approver')
    finance_approved_requests = db.relationship('ReimbursementRequest', foreign_keys='ReimbursementRequest.finance_approver_id', back_populates='finance_approver')


class Department(db.Model):
    __tablename__ = 'departments'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    users = db.relationship('User', back_populates='department')
    manager = db.relationship('User', foreign_keys=[manager_id])


class ExpenseCategory(db.Model):
    __tablename__ = 'expense_categories'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    code = db.Column(db.String(50), unique=True, nullable=False)
    description = db.Column(db.Text)

    items = db.relationship('ReimbursementItem', back_populates='category')


class ReimbursementRequest(db.Model):
    __tablename__ = 'reimbursement_requests'

    id = db.Column(db.Integer, primary_key=True)
    applicant_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    total_amount = db.Column(db.Numeric(10, 2), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    dept_approver_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    dept_approved_at = db.Column(db.DateTime)
    finance_approver_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    finance_approved_at = db.Column(db.DateTime)
    reject_reason = db.Column(db.Text)

    applicant = db.relationship('User', foreign_keys=[applicant_id], back_populates='reimbursement_requests')
    dept_approver = db.relationship('User', foreign_keys=[dept_approver_id], back_populates='dept_approved_requests')
    finance_approver = db.relationship('User', foreign_keys=[finance_approver_id], back_populates='finance_approved_requests')
    items = db.relationship('ReimbursementItem', back_populates='request', cascade='all, delete-orphan')


class ReimbursementItem(db.Model):
    __tablename__ = 'reimbursement_items'

    id = db.Column(db.Integer, primary_key=True)
    request_id = db.Column(db.Integer, db.ForeignKey('reimbursement_requests.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('expense_categories.id'), nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    description = db.Column(db.Text)
    receipt_image = db.Column(db.String(500))
    expense_date = db.Column(db.Date, nullable=False)

    request = db.relationship('ReimbursementRequest', back_populates='items')
    category = db.relationship('ExpenseCategory', back_populates='items')
