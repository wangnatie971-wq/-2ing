from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from models import db, ReimbursementRequest
from datetime import datetime

approval_bp = Blueprint('approval', __name__, url_prefix='/approval')


@approval_bp.route('/department')
@login_required
def department():
    if current_user.role not in ['manager', 'admin']:
        flash('您没有权限访问此页面', 'danger')
        return redirect(url_for('main.index'))

    requests = ReimbursementRequest.query.filter_by(status='pending').join(
        ReimbursementRequest.applicant
    ).filter_by(department_id=current_user.department_id).order_by(
        ReimbursementRequest.created_at.desc()
    ).all()

    return render_template('approval/dept_approval.html', requests=requests)


@approval_bp.route('/department/approve/<int:request_id>', methods=['POST'])
@login_required
def department_approve(request_id):
    if current_user.role not in ['manager', 'admin']:
        flash('您没有权限访问此页面', 'danger')
        return redirect(url_for('main.index'))

    reimbursement = ReimbursementRequest.query.get_or_404(request_id)

    if reimbursement.status != 'pending':
        flash('该申请已被处理', 'warning')
        return redirect(url_for('approval.department'))

    if reimbursement.applicant.department_id != current_user.department_id:
        flash('您只能审批本部门的报销申请', 'danger')
        return redirect(url_for('approval.department'))

    reimbursement.status = 'dept_approved'
    reimbursement.dept_approver_id = current_user.id
    reimbursement.dept_approved_at = datetime.utcnow()

    db.session.commit()
    flash('部门审批通过', 'success')
    return redirect(url_for('approval.department'))


@approval_bp.route('/department/reject/<int:request_id>', methods=['POST'])
@login_required
def department_reject(request_id):
    if current_user.role not in ['manager', 'admin']:
        flash('您没有权限访问此页面', 'danger')
        return redirect(url_for('main.index'))

    reimbursement = ReimbursementRequest.query.get_or_404(request_id)

    if reimbursement.status != 'pending':
        flash('该申请已被处理', 'warning')
        return redirect(url_for('approval.department'))

    if reimbursement.applicant.department_id != current_user.department_id:
        flash('您只能审批本部门的报销申请', 'danger')
        return redirect(url_for('approval.department'))

    reject_reason = request.form.get('reject_reason')
    if not reject_reason:
        flash('请填写驳回原因', 'warning')
        return redirect(url_for('approval.department'))

    reimbursement.status = 'rejected'
    reimbursement.dept_approver_id = current_user.id
    reimbursement.dept_approved_at = datetime.utcnow()
    reimbursement.reject_reason = reject_reason

    db.session.commit()
    flash('已驳回报销申请', 'success')
    return redirect(url_for('approval.department'))


@approval_bp.route('/finance')
@login_required
def finance():
    if current_user.role not in ['finance', 'admin']:
        flash('您没有权限访问此页面', 'danger')
        return redirect(url_for('main.index'))

    requests = ReimbursementRequest.query.filter_by(
        status='dept_approved'
    ).order_by(ReimbursementRequest.dept_approved_at.desc()).all()

    return render_template('approval/finance_approval.html', requests=requests)


@approval_bp.route('/finance/approve/<int:request_id>', methods=['POST'])
@login_required
def finance_approve(request_id):
    if current_user.role not in ['finance', 'admin']:
        flash('您没有权限访问此页面', 'danger')
        return redirect(url_for('main.index'))

    reimbursement = ReimbursementRequest.query.get_or_404(request_id)

    if reimbursement.status != 'dept_approved':
        flash('该申请已被处理', 'warning')
        return redirect(url_for('approval.finance'))

    reimbursement.status = 'approved'
    reimbursement.finance_approver_id = current_user.id
    reimbursement.finance_approved_at = datetime.utcnow()

    db.session.commit()
    flash('财务审批通过，报销流程完成', 'success')
    return redirect(url_for('approval.finance'))


@approval_bp.route('/finance/reject/<int:request_id>', methods=['POST'])
@login_required
def finance_reject(request_id):
    if current_user.role not in ['finance', 'admin']:
        flash('您没有权限访问此页面', 'danger')
        return redirect(url_for('main.index'))

    reimbursement = ReimbursementRequest.query.get_or_404(request_id)

    if reimbursement.status != 'dept_approved':
        flash('该申请已被处理', 'warning')
        return redirect(url_for('approval.finance'))

    reject_reason = request.form.get('reject_reason')
    if not reject_reason:
        flash('请填写驳回原因', 'warning')
        return redirect(url_for('approval.finance'))

    reimbursement.status = 'rejected'
    reimbursement.finance_approver_id = current_user.id
    reimbursement.finance_approved_at = datetime.utcnow()
    reimbursement.reject_reason = reject_reason

    db.session.commit()
    flash('已驳回报销申请', 'success')
    return redirect(url_for('approval.finance'))
