from flask import Blueprint, render_template
from flask_login import login_required, current_user
from models import db, ReimbursementRequest

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
@login_required
def index():
    role = current_user.role

    if role == 'employee':
        pending_count = ReimbursementRequest.query.filter_by(applicant_id=current_user.id, status='pending').count()
        my_requests = ReimbursementRequest.query.filter_by(applicant_id=current_user.id).count()
        approved_count = ReimbursementRequest.query.filter_by(applicant_id=current_user.id, status='approved').count()
        rejected_count = ReimbursementRequest.query.filter_by(applicant_id=current_user.id, status='rejected').count()
        recent_requests = ReimbursementRequest.query.filter_by(applicant_id=current_user.id).order_by(ReimbursementRequest.created_at.desc()).limit(5).all()
        todos = []

    elif role == 'manager':
        pending_count = ReimbursementRequest.query.filter_by(status='pending').join(ReimbursementRequest.applicant).filter_by(department_id=current_user.department_id).count()
        my_requests = ReimbursementRequest.query.filter_by(applicant_id=current_user.id).count()
        approved_count = ReimbursementRequest.query.filter_by(dept_approver_id=current_user.id, status='dept_approved').count()
        rejected_count = ReimbursementRequest.query.filter_by(dept_approver_id=current_user.id, status='rejected').count()
        recent_requests = ReimbursementRequest.query.join(ReimbursementRequest.applicant).filter_by(department_id=current_user.department_id).order_by(ReimbursementRequest.created_at.desc()).limit(5).all()
        todos = [
            {'title': '部门报销审批', 'description': '待审批报销单', 'count': pending_count}
        ]

    elif role == 'finance':
        pending_count = ReimbursementRequest.query.filter_by(status='dept_approved').count()
        my_requests = ReimbursementRequest.query.filter_by(applicant_id=current_user.id).count()
        approved_count = ReimbursementRequest.query.filter_by(finance_approver_id=current_user.id, status='approved').count()
        rejected_count = ReimbursementRequest.query.filter_by(finance_approver_id=current_user.id, status='rejected').count()
        recent_requests = ReimbursementRequest.query.filter_by(status='dept_approved').order_by(ReimbursementRequest.created_at.desc()).limit(5).all()
        todos = [
            {'title': '财务报销审批', 'description': '待审批报销单', 'count': pending_count}
        ]

    elif role == 'admin':
        pending_count = ReimbursementRequest.query.filter(ReimbursementRequest.status.in_(['pending', 'dept_approved'])).count()
        my_requests = ReimbursementRequest.query.filter_by(applicant_id=current_user.id).count()
        approved_count = ReimbursementRequest.query.filter_by(status='approved').count()
        rejected_count = ReimbursementRequest.query.filter_by(status='rejected').count()
        recent_requests = ReimbursementRequest.query.order_by(ReimbursementRequest.created_at.desc()).limit(5).all()
        todos = []

    else:
        pending_count = 0
        my_requests = 0
        approved_count = 0
        rejected_count = 0
        recent_requests = []
        todos = []

    stats = {
        'pending_count': pending_count,
        'approved_count': approved_count,
        'my_requests': my_requests,
        'rejected_count': rejected_count
    }

    return render_template('index.html', stats=stats, recent_requests=recent_requests, todos=todos)
