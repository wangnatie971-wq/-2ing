from flask import Blueprint, render_template, redirect, url_for, flash, request, make_response
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from models import db, ReimbursementRequest, ReimbursementItem, ExpenseCategory
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
import os

reimbursement_bp = Blueprint('reimbursement', __name__, url_prefix='/reimbursement')

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'pdf'}

UPLOAD_FOLDER = 'uploads/receipts'


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@reimbursement_bp.route('/apply', methods=['GET', 'POST'])
@login_required
def apply():
    categories = ExpenseCategory.query.all()

    if request.method == 'POST':
        title = request.form.get('title')
        items_data = request.form.getlist('items')

        total_amount = 0
        items = []

        for i in range(len(request.form.getlist('items[category_id]'))):
            category_id = request.form.get(f'items[{i}][category_id]')
            amount = request.form.get(f'items[{i}][amount]')
            expense_date = request.form.get(f'items[{i}][expense_date]')
            description = request.form.get(f'items[{i}][description]')

            if category_id and amount and expense_date:
                total_amount += float(amount)
                items.append({
                    'category_id': int(category_id),
                    'amount': float(amount),
                    'expense_date': datetime.strptime(expense_date, '%Y-%m-%d').date(),
                    'description': description or ''
                })

        if not items:
            flash('请至少添加一条费用明细', 'warning')
            return redirect(url_for('reimbursement.apply'))

        reimbursement = ReimbursementRequest(
            applicant_id=current_user.id,
            title=title,
            total_amount=total_amount,
            status='pending'
        )
        db.session.add(reimbursement)
        db.session.flush()

        for item_data in items:
            item = ReimbursementItem(
                request_id=reimbursement.id,
                category_id=item_data['category_id'],
                amount=item_data['amount'],
                expense_date=item_data['expense_date'],
                description=item_data['description']
            )
            db.session.add(item)

        db.session.commit()
        flash('报销申请提交成功', 'success')
        return redirect(url_for('reimbursement.my_list'))

    return render_template('reimbursement/apply.html', categories=categories)


@reimbursement_bp.route('/my-list')
@login_required
def my_list():
    requests = ReimbursementRequest.query.filter_by(
        applicant_id=current_user.id
    ).order_by(ReimbursementRequest.created_at.desc()).all()
    return render_template('reimbursement/my_list.html', requests=requests)


@reimbursement_bp.route('/detail/<int:request_id>')
@login_required
def detail(request_id):
    reimbursement = ReimbursementRequest.query.get_or_404(request_id)

    if reimbursement.applicant_id != current_user.id and current_user.role not in ['manager', 'finance', 'admin']:
        flash('您没有权限查看此报销申请', 'danger')
        return redirect(url_for('reimbursement.my_list'))

    return render_template('reimbursement/detail.html', reimbursement=reimbursement)


@reimbursement_bp.route('/export')
@login_required
def export():
    if current_user.role not in ['manager', 'finance', 'admin']:
        flash('您没有权限导出数据', 'danger')
        return redirect(url_for('main.index'))

    if current_user.role == 'manager':
        requests = ReimbursementRequest.query.join(ReimbursementRequest.applicant).filter_by(
            department_id=current_user.department_id
        ).order_by(ReimbursementRequest.created_at.desc()).all()
    else:
        requests = ReimbursementRequest.query.order_by(ReimbursementRequest.created_at.desc()).all()

    wb = Workbook()
    ws = wb.active
    ws.title = '报销记录'

    header_fill = PatternFill(start_color='667EEA', end_color='667EEA', fill_type='solid')
    header_font = Font(color='FFFFFF', bold=True)
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    headers = ['申请人', '部门', '报销标题', '金额', '状态', '申请时间', '部门审批时间', '财务审批时间', '驳回原因']
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = thin_border

    status_map = {
        'pending': '待审批',
        'dept_approved': '部门已审',
        'approved': '已通过',
        'rejected': '已驳回'
    }

    for row, req in enumerate(requests, 2):
        ws.cell(row=row, column=1, value=req.applicant.real_name).border = thin_border
        ws.cell(row=row, column=2, value=req.applicant.department.name if req.applicant.department else '-').border = thin_border
        ws.cell(row=row, column=3, value=req.title).border = thin_border
        ws.cell(row=row, column=4, value=float(req.total_amount)).border = thin_border
        ws.cell(row=row, column=5, value=status_map.get(req.status, req.status)).border = thin_border
        ws.cell(row=row, column=6, value=req.created_at.strftime('%Y-%m-%d %H:%M') if req.created_at else '-').border = thin_border
        ws.cell(row=row, column=7, value=req.dept_approved_at.strftime('%Y-%m-%d %H:%M') if req.dept_approved_at else '-').border = thin_border
        ws.cell(row=row, column=8, value=req.finance_approved_at.strftime('%Y-%m-%d %H:%M') if req.finance_approved_at else '-').border = thin_border
        ws.cell(row=row, column=9, value=req.reject_reason or '-').border = thin_border

    for col in range(1, len(headers) + 1):
        ws.column_dimensions[chr(64 + col)].width = 15

    ws.column_dimensions['A'].width = 10
    ws.column_dimensions['B'].width = 12
    ws.column_dimensions['C'].width = 25
    ws.column_dimensions['D'].width = 12
    ws.column_dimensions['E'].width = 10
    ws.column_dimensions['F'].width = 18
    ws.column_dimensions['G'].width = 18
    ws.column_dimensions['H'].width = 18
    ws.column_dimensions['I'].width = 20

    response = make_response()
    wb.save(response)
    response.headers['Content-Type'] = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    response.headers['Content-Disposition'] = f'attachment; filename=reimbursement_{datetime.now().strftime("%Y%m%d%H%M%S")}.xlsx'

    return response
