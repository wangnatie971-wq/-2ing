from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from sqlalchemy import Column, Integer, String, Boolean, DateTime
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()


class Role(Base):
    __tablename__ = 'roles'
    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)
    description = Column(String(200))

class User(UserMixin, Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)
    password_hash = Column(String(128), nullable=False)
    real_name = Column(String(100))
    role = Column(String(20), nullable=False)
    email = Column(String(100), unique=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def set_password(self, password):
        from werkzeug.security import generate_password_hash
        # 使用与Werkzeug 2.0.1兼容的方式
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        from werkzeug.security import check_password_hash
        # 确保password_hash存在且格式正确
        if not self.password_hash or not isinstance(self.password_hash, str):
            return False
        # 尝试使用check_password_hash验证密码
        try:
            return check_password_hash(self.password_hash, password)
        except Exception:
            # 如果验证失败（比如哈希格式错误），返回False
            return False


class Cabinet(Base):
    __tablename__ = 'cabinets'
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    room = Column(String(100), nullable=False)
    rack_units = Column(Integer, nullable=False)
    used_units = Column(Integer, default=0)
    power_capacity = Column(Integer)
    remark = Column(String(200))


class Asset(Base):
    __tablename__ = 'assets'
    id = Column(Integer, primary_key=True)
    asset_no = Column(String(50), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    type = Column(String(20), nullable=False)  # server/switch/router/firewall/ups
    brand = Column(String(50))
    model = Column(String(100))
    sn = Column(String(100))
    cabinet_id = Column(Integer)
    rack_start_u = Column(Integer)
    status = Column(String(20), default='idle')  # online/offline/idle/maintenance
    ip_address = Column(String(50))
    os = Column(String(100))
    cpu = Column(String(100))
    memory = Column(String(50))
    disk = Column(String(200))
    purchase_date = Column(DateTime)
    warranty_end = Column(DateTime)
    create_time = Column(DateTime, default=datetime.utcnow)
    update_time = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AssetLog(Base):
    __tablename__ = 'asset_logs'
    id = Column(Integer, primary_key=True)
    asset_id = Column(Integer, nullable=False)
    action = Column(String(50), nullable=False)
    operator = Column(String(50), nullable=False)
    detail = Column(String(500))
    create_time = Column(DateTime, default=datetime.utcnow)


class WorkOrder(Base):
    __tablename__ = 'work_orders'
    id = Column(Integer, primary_key=True)
    title = Column(String(200), nullable=False)
    type = Column(String(20), nullable=False)  # fault/change/inspect/deploy
    priority = Column(String(20), nullable=False)  # critical/high/medium/low
    status = Column(String(20), default='pending')  # pending/processing/accepted/completed/closed
    asset_id = Column(Integer)
    asset_name = Column(String(100))
    assignee_id = Column(Integer)
    creator_id = Column(Integer, nullable=False)
    description = Column(String(1000))
    resolution = Column(String(1000))
    sla_deadline = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class WorkOrderLog(Base):
    __tablename__ = 'work_order_logs'
    id = Column(Integer, primary_key=True)
    order_id = Column(Integer, nullable=False)
    action = Column(String(50), nullable=False)
    operator_id = Column(Integer, nullable=False)
    content = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)


class MonitorData(Base):
    __tablename__ = 'monitor_data'
    id = Column(Integer, primary_key=True)
    asset_id = Column(Integer, nullable=False)
    cpu_usage = Column(Integer, nullable=False)  # 0-100
    mem_usage = Column(Integer, nullable=False)  # 0-100
    disk_usage = Column(Integer, nullable=False)  # 0-100
    network_in = Column(Integer)  # bytes
    network_out = Column(Integer)  # bytes
    ping_status = Column(Integer, default=1)  # 0: 离线, 1: 在线
    collected_at = Column(DateTime, default=datetime.utcnow)


class AlertRule(Base):
    __tablename__ = 'alert_rules'
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    metric = Column(String(20), nullable=False)  # cpu/mem/disk/ping
    condition = Column(String(10), nullable=False)  # gt/lt/eq
    threshold = Column(Integer, nullable=False)
    level = Column(String(20), nullable=False)  # critical/warning/info
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AlertRecord(Base):
    __tablename__ = 'alert_records'
    id = Column(Integer, primary_key=True)
    rule_id = Column(Integer, nullable=False)
    asset_id = Column(Integer, nullable=False)
    asset_name = Column(String(100), nullable=False)
    metric = Column(String(20), nullable=False)
    value = Column(Integer, nullable=False)
    threshold = Column(Integer, nullable=False)
    level = Column(String(20), nullable=False)
    status = Column(String(20), default='active')  # active/acknowledged/resolved
    message = Column(String(500), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    resolved_at = Column(DateTime)


class Subnet(Base):
    __tablename__ = 'subnets'
    id = Column(Integer, primary_key=True)
    network = Column(String(20), nullable=False)  # 如 10.0.1.0
    prefix_len = Column(Integer, nullable=False)  # 如 24
    gateway = Column(String(20), nullable=False)
    vlan_id = Column(Integer)
    purpose = Column(String(100))
    room = Column(String(100))
    used_count = Column(Integer, default=0)
    total_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class IPAddress(Base):
    __tablename__ = 'ip_addresses'
    id = Column(Integer, primary_key=True)
    address = Column(String(20), nullable=False)
    subnet_id = Column(Integer, nullable=False)
    asset_id = Column(Integer)
    status = Column(String(10), default='free')  # used/free/reserved
    updated_at = Column(DateTime, default=datetime.utcnow)


class OperationLog(Base):
    __tablename__ = 'operation_logs'
    id = Column(Integer, primary_key=True)
    operator = Column(String(50), nullable=False)
    action = Column(String(100), nullable=False)
    target_type = Column(String(50))
    target_id = Column(Integer)
    detail = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)
