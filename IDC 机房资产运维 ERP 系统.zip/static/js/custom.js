// 自定义JavaScript

// 初始化图表
function initCharts() {
    // 图表初始化逻辑
}

// 响应式调整
function resizeCharts() {
    // 图表响应式调整逻辑
}

// 页面加载完成后执行
window.addEventListener('load', function() {
    initCharts();
});

// 窗口大小改变时执行
window.addEventListener('resize', function() {
    resizeCharts();
});
