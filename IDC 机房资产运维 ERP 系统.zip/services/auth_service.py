from models.models import User
from app import session

class AuthService:
    @staticmethod
    def authenticate_user(username, password):
        """验证用户身份"""
        user = session.query(User).filter_by(username=username).first()
        if user and user.check_password(password):
            return user
        return None
    
    @staticmethod
    def create_user(username, password, real_name, role, email):
        """创建新用户"""
        # 检查用户名是否已存在
        existing_user = session.query(User).filter_by(username=username).first()
        if existing_user:
            return None
        
        # 创建新用户
        new_user = User(
            username=username,
            real_name=real_name,
            role=role,
            email=email
        )
        new_user.set_password(password)
        session.add(new_user)
        session.commit()
        return new_user
    
    @staticmethod
    def get_user_by_id(user_id):
        """根据ID获取用户"""
        return session.query(User).get(user_id)
    
    @staticmethod
    def get_user_by_username(username):
        """根据用户名获取用户"""
        return session.query(User).filter_by(username=username).first()
