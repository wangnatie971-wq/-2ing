import random
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from models.models import Asset, MonitorData, AlertRule, AlertRecord, WorkOrder, WorkOrderLog
from app import session


class MonitorService:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.asset_metrics = {}  # 存储每个资产的当前指标，用于模拟波动
    
    def start(self):
        # 启动调度器
        self.scheduler.add_job(self.collect_data, 'interval', minutes=1, id='collect_monitor_data')
        self.scheduler.start()
        print("监控服务已启动，每分钟采集一次数据")
    
    def stop(self):
        # 停止调度器
        self.scheduler.shutdown()
        print("监控服务已停止")
    
    def collect_data(self):
        # 获取所有在线设备
        online_assets = session.query(Asset).filter_by(status='online').all()
        
        for asset in online_assets:
            # 生成模拟数据
            cpu_usage = self._generate_cpu_usage(asset.id)
            mem_usage = self._generate_mem_usage(asset.id)
            disk_usage = self._generate_disk_usage(asset.id)
            network_in = random.randint(1000, 100000)  # 1KB-100KB
            network_out = random.randint(1000, 50000)  # 1KB-50KB
            ping_status = self._generate_ping_status()
            
            # 创建监控数据记录
            monitor_data = MonitorData(
                asset_id=asset.id,
                cpu_usage=cpu_usage,
                mem_usage=mem_usage,
                disk_usage=disk_usage,
                network_in=network_in,
                network_out=network_out,
                ping_status=ping_status,
                collected_at=datetime.utcnow()
            )
            
            session.add(monitor_data)
        
        # 提交事务
        try:
            session.commit()
            print(f"采集了 {len(online_assets)} 台设备的监控数据")
        except Exception as e:
            session.rollback()
            print(f"采集数据时出错：{e}")
        
        # 检查告警规则
        self._check_alert_rules()
    
    def _generate_cpu_usage(self, asset_id):
        # 生成CPU使用率，在20-95%之间波动
        if asset_id not in self.asset_metrics:
            self.asset_metrics[asset_id] = {
                'cpu': random.randint(20, 95),
                'mem': random.randint(30, 90),
                'disk': random.randint(20, 80)
            }
        
        # 随机波动，范围为-5到+5
        fluctuation = random.randint(-5, 5)
        new_cpu = self.asset_metrics[asset_id]['cpu'] + fluctuation
        
        # 确保在范围内
        new_cpu = max(20, min(95, new_cpu))
        self.asset_metrics[asset_id]['cpu'] = new_cpu
        
        return new_cpu
    
    def _generate_mem_usage(self, asset_id):
        # 生成内存使用率，在30-90%之间波动
        if asset_id not in self.asset_metrics:
            self.asset_metrics[asset_id] = {
                'cpu': random.randint(20, 95),
                'mem': random.randint(30, 90),
                'disk': random.randint(20, 80)
            }
        
        # 随机波动，范围为-3到+3
        fluctuation = random.randint(-3, 3)
        new_mem = self.asset_metrics[asset_id]['mem'] + fluctuation
        
        # 确保在范围内
        new_mem = max(30, min(90, new_mem))
        self.asset_metrics[asset_id]['mem'] = new_mem
        
        return new_mem
    
    def _generate_disk_usage(self, asset_id):
        # 生成磁盘使用率，在20-80%之间波动
        if asset_id not in self.asset_metrics:
            self.asset_metrics[asset_id] = {
                'cpu': random.randint(20, 95),
                'mem': random.randint(30, 90),
                'disk': random.randint(20, 80)
            }
        
        # 随机波动，范围为-1到+1
        fluctuation = random.randint(-1, 1)
        new_disk = self.asset_metrics[asset_id]['disk'] + fluctuation
        
        # 确保在范围内
        new_disk = max(20, min(80, new_disk))
        self.asset_metrics[asset_id]['disk'] = new_disk
        
        return new_disk
    
    def _generate_ping_status(self):
        # 2%概率生成ping超时（模拟设备离线）
        if random.random() < 0.02:
            return 0  # 离线
        return 1  # 在线
    
    def _check_alert_rules(self):
        # 获取所有启用的告警规则
        enabled_rules = session.query(AlertRule).filter_by(enabled=True).all()
        
        if not enabled_rules:
            print("没有启用的告警规则")
            return
        
        # 获取所有设备的最新监控数据
        assets = session.query(Asset).all()
        
        for asset in assets:
            # 获取最新的监控数据
            latest_data = session.query(MonitorData).filter_by(asset_id=asset.id).order_by(MonitorData.collected_at.desc()).first()
            if not latest_data:
                continue
            
            # 检查每个告警规则
            for rule in enabled_rules:
                # 检查告警条件
                if self._check_alert_condition(latest_data, rule):
                    # 检查是否已经有相同的活跃告警
                    existing_alert = session.query(AlertRecord).filter(
                        AlertRecord.rule_id == rule.id,
                        AlertRecord.asset_id == asset.id,
                        AlertRecord.status.in_(['active', 'acknowledged'])
                    ).first()
                    
                    if not existing_alert:
                        # 创建新的告警记录
                        alert_message = f"{asset.name} - {rule.name}: {self._get_metric_value(latest_data, rule.metric)} {self._get_condition_symbol(rule.condition)} {rule.threshold}"
                        
                        new_alert = AlertRecord(
                            rule_id=rule.id,
                            asset_id=asset.id,
                            asset_name=asset.name,
                            metric=rule.metric,
                            value=self._get_metric_value(latest_data, rule.metric),
                            threshold=rule.threshold,
                            level=rule.level,
                            message=alert_message
                        )
                        
                        session.add(new_alert)
                        session.commit()
                        
                        print(f"告警：{alert_message}")
                        
                        # 如果是严重告警，创建工单
                        if rule.level == 'critical':
                            self._create_workorder_for_alert(asset, alert_message)
    
    def _check_alert_condition(self, monitor_data, rule):
        # 检查告警条件
        value = self._get_metric_value(monitor_data, rule.metric)
        
        if rule.condition == 'gt':
            return value > rule.threshold
        elif rule.condition == 'lt':
            return value < rule.threshold
        elif rule.condition == 'eq':
            return value == rule.threshold
        
        return False
    
    def _get_metric_value(self, monitor_data, metric):
        # 获取监控指标值
        if metric == 'cpu':
            return monitor_data.cpu_usage
        elif metric == 'mem':
            return monitor_data.mem_usage
        elif metric == 'disk':
            return monitor_data.disk_usage
        elif metric == 'ping':
            return monitor_data.ping_status
        
        return 0
    
    def _get_condition_symbol(self, condition):
        # 获取条件符号
        if condition == 'gt':
            return '>'
        elif condition == 'lt':
            return '<'
        elif condition == 'eq':
            return '='
        
        return ''
    
    def _create_workorder_for_alert(self, asset, alert_message):
        # 为严重告警创建工单
        new_order = WorkOrder(
            title=f'【严重告警】{asset.name}',
            type='fault',
            priority='critical',
            status='pending',
            asset_id=asset.id,
            asset_name=asset.name,
            creator_id=1,  # 默认创建人
            description=alert_message
        )
        
        session.add(new_order)
        session.commit()
        
        # 记录操作日志
        log = WorkOrderLog(
            order_id=new_order.id,
            action='创建工单',
            operator_id=1,
            content=f'由严重告警自动创建工单：{alert_message}'
        )
        session.add(log)
        session.commit()
        
        print(f"为设备 {asset.name} 创建了故障工单")


# 创建监控服务实例
monitor_service = MonitorService()
