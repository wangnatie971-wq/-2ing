from models.models import OperationLog
from app import session


def log_operation(operator, action, target_type=None, target_id=None, detail=None):
    """记录操作日志
    
    Args:
        operator: 操作人
        action: 操作类型
        target_type: 操作对象类型
        target_id: 操作对象ID
        detail: 操作详情
    """
    try:
        log = OperationLog(
            operator=operator,
            action=action,
            target_type=target_type,
            target_id=target_id,
            detail=detail
        )
        session.add(log)
        session.commit()
    except Exception as e:
        print(f"记录操作日志失败: {str(e)}")
        session.rollback()
