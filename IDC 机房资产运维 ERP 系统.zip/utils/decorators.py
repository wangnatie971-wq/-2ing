from flask import redirect, url_for
from flask_login import current_user
from functools import wraps


def login_required(f):
    """登录保护装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function


def admin_required(f):
    """管理员权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if current_user.role != 'admin':
            # 无权限访问
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated_function


def engineer_required(f):
    """工程师权限装饰器"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        if current_user.role not in ['admin', 'engineer']:
            # 无权限访问
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated_function
