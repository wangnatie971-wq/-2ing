from functools import wraps
from flask import redirect, url_for, flash
from flask_login import current_user

# 角色权限定义
ROLES = {
    'admin': {
        'permissions': ['all']
    },
    'engineer': {
        'permissions': ['asset_management', 'workorder_processing', 'monitor_viewing']
    },
    'viewer': {
        'permissions': ['read_only']
    }
}

# 权限检查装饰器
def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for('auth.login'))
            
            # 检查用户角色
            user_role = current_user.role
            
            # admin 角色拥有所有权限
            if user_role == 'admin':
                return f(*args, **kwargs)
            
            # 检查用户是否有相应权限
            if user_role in ROLES:
                user_permissions = ROLES[user_role]['permissions']
                
                # 如果用户有 'all' 权限或者明确拥有该权限
                if 'all' in user_permissions or permission in user_permissions:
                    return f(*args, **kwargs)
                
                # viewer 角色只能查看
                if user_role == 'viewer' and permission == 'read_only':
                    return f(*args, **kwargs)
            
            flash('您没有权限访问该页面')
            return redirect(url_for('dashboard.index'))
        return decorated_function
    return decorator

# 检查是否为管理员
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for('auth.login'))
        
        if current_user.role != 'admin':
            flash('只有管理员可以访问该页面')
            return redirect(url_for('dashboard.index'))
        
        return f(*args, **kwargs)
    return decorated_function
