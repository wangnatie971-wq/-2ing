import time
import random
import string
from datetime import datetime


def generate_random_string(length=10):
    """生成随机字符串"""
    letters = string.ascii_letters + string.digits
    return ''.join(random.choice(letters) for _ in range(length))


def timestamp_to_datetime(timestamp):
    """时间戳转换为datetime对象"""
    return datetime.fromtimestamp(timestamp)


def datetime_to_timestamp(dt):
    """datetime对象转换为时间戳"""
    return int(time.mktime(dt.timetuple()))


def format_datetime(dt, format='%Y-%m-%d %H:%M:%S'):
    """格式化datetime对象"""
    return dt.strftime(format)


def parse_datetime(date_string, format='%Y-%m-%d %H:%M:%S'):
    """解析日期字符串为datetime对象"""
    return datetime.strptime(date_string, format)


def get_current_datetime():
    """获取当前datetime对象"""
    return datetime.now()


def get_current_timestamp():
    """获取当前时间戳"""
    return int(time.time())
