DROP DATABASE IF EXISTS idc_oms;
CREATE DATABASE idc_oms CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE idc_oms;

-- 角色表
CREATE TABLE roles (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) UNIQUE NOT NULL,
    description VARCHAR(200)
);

-- 用户表
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(128) NOT NULL,
    real_name VARCHAR(100),
    role VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE,
    is_active TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 机柜表
CREATE TABLE cabinets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    room VARCHAR(100) NOT NULL,
    rack_units INT NOT NULL,
    used_units INT DEFAULT 0,
    power_capacity INT,
    remark VARCHAR(200)
);

-- 资产表（MySQL5.5专用：只保留1个自动时间戳）
CREATE TABLE assets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    asset_no VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    type VARCHAR(20) NOT NULL,
    brand VARCHAR(50),
    model VARCHAR(100),
    sn VARCHAR(100),
    cabinet_id INT,
    rack_start_u INT,
    status VARCHAR(20) DEFAULT 'idle',
    ip_address VARCHAR(50),
    os VARCHAR(100),
    cpu VARCHAR(100),
    memory VARCHAR(50),
    disk VARCHAR(200),
    purchase_date DATETIME NULL,
    warranty_end DATETIME NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME NULL  -- 这里改成 DATETIME，不自动更新！解决报错
);

-- 日志表
CREATE TABLE asset_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    asset_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    operator VARCHAR(50) NOT NULL,
    detail VARCHAR(500),
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ====================== 插入数据 ======================
INSERT INTO roles (name, description) VALUES ('admin', '系统管理员');
INSERT INTO roles (name, description) VALUES ('engineer', '工程师');
INSERT INTO roles (name, description) VALUES ('viewer', '查看人员');

INSERT INTO users (username,password_hash,real_name,role,email,is_active)
VALUES ('admin','$pbkdf2:sha256:260000$0R2n2q9N4h7e8w5b$9e1f0c7e8a9b0d6f2a3b4c5d6e7f8g9h0i1j2k3l4m5n6o7p8q9r0s','系统管理员','admin','admin@example.com',1);

INSERT INTO cabinets (name,room,rack_units,power_capacity,remark) VALUES ('A01','机房1',42,10000,'主设备区');
INSERT INTO cabinets (name,room,rack_units,power_capacity,remark) VALUES ('A02','机房1',42,10000,'网络设备区');
INSERT INTO cabinets (name,room,rack_units,power_capacity,remark) VALUES ('B01','机房2',42,8000,'备用设备区');

INSERT INTO assets (asset_no,name,type,brand,model,sn,cabinet_id,rack_start_u,status,ip_address,os,cpu,memory,disk)
VALUES ('SVR-001','Web服务器1','server','Dell','R740','SN123456',1,1,'online','192.168.1.100','Ubuntu 20.04','Intel Xeon 8C','32GB','2TB SSD');

INSERT INTO assets (asset_no,name,type,brand,model,sn,cabinet_id,rack_start_u,status,ip_address)
VALUES ('SW-001','核心交换机','switch','Cisco','C9300','SN654321',2,1,'online','192.168.1.1');

INSERT INTO assets (asset_no,name,type,brand,model,sn,cabinet_id,rack_start_u,status,ip_address)
VALUES ('RTR-001','边界路由器','router','H3C','MSR3600','SN789012',2,5,'online','192.168.1.2');

INSERT INTO assets (asset_no,name,type,brand,model,sn,cabinet_id,rack_start_u,status,ip_address)
VALUES ('FW-001','防火墙','firewall','Huawei','USG6000','SN345678',2,9,'online','192.168.1.3');

INSERT INTO assets (asset_no,name,type,brand,model,sn,cabinet_id,rack_start_u,status)
VALUES ('UPS-001','不间断电源','ups','APC','SURT10000XLI','SN987654',3,1,'online');