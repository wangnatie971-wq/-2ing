from flask import Flask
from flask_login import LoginManager
from config import Config
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

app = Flask(__name__)
app.config.from_object(Config)
login_manager = LoginManager(app)
login_manager.login_view = 'auth.login'

# ===================== 数据库连接（稳定版）=====================
engine = create_engine(
    'mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8',
    pool_pre_ping=True,  # 自动检查连接
    pool_recycle=3600    # 自动重连
)
Session = sessionmaker(bind=engine, autoflush=False)

# 每次获取 session
def get_db_session():
    db = Session()
    try:
        db.execute("SELECT 1")  # 测试连接
    except:
        db.rollback()  # 出错自动回滚
    return db

# ===================== 初始化表 =====================
from models.models import Base, User
Base.metadata.create_all(engine)

# ===================== 注册蓝图 =====================
def create_app():
    from routes.auth import bp as auth_bp
    from routes.dashboard import bp as dashboard_bp
    from routes.asset import bp as asset_bp
    from routes.workorder import bp as workorder_bp
    from routes.monitor import bp as monitor_bp
    from routes.ip import bp as ip_bp
    from routes.report import bp as report_bp
    from routes.system import bp as system_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(asset_bp)
    app.register_blueprint(workorder_bp)
    app.register_blueprint(monitor_bp)
    app.register_blueprint(ip_bp)
    app.register_blueprint(report_bp)
    app.register_blueprint(system_bp)

# 默认跳转到登录页
@app.route('/')
def index():
    from flask import redirect, url_for
    return redirect(url_for('auth.login'))

# ===================== 登录用户加载 =====================
@login_manager.user_loader
def load_user(user_id):
    session = get_db_session()
    try:
        user = session.query(User).get(int(user_id))
    finally:
        session.close()
    return user

# ===================== 启动 =====================
if __name__ == '__main__':
    create_app()
    app.run(debug=True)