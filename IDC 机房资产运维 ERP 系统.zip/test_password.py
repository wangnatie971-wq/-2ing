# 测试密码哈希功能

print("测试密码哈希功能...")

try:
    from werkzeug.security import generate_password_hash, check_password_hash
    print("Successfully imported Werkzeug security module")
    
    # 测试密码哈希生成
    password = "test123"
    hashed = generate_password_hash(password)
    print(f"Successfully generated password hash: {hashed[:20]}...")
    
    # 测试密码验证
    result = check_password_hash(hashed, password)
    print(f"Password validation result: {result}")
    
    # 测试错误密码
    wrong_result = check_password_hash(hashed, "wrongpassword")
    print(f"Wrong password validation result: {wrong_result}")
    
    print("Password hash functionality test successful!")
except Exception as e:
    print(f"Test failed: {e}")
