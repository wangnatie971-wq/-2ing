import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-idc-oms'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:password@localhost/idc_oms'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    PERMANENT_SESSION_LIFETIME = 86400
