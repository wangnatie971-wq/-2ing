from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required
from utils.permission import admin_required
from models.models import AlertRule
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('system', __name__)


@bp.route('/system/settings')
@login_required
@admin_required
def settings():
    session = Session()
    try:
        # 获取所有告警规则
        alert_rules = session.query(AlertRule).all()
        
        return render_template('system/settings.html', alert_rules=alert_rules)
    finally:
        session.close()


@bp.route('/system/update_alert_rule/<int:rule_id>', methods=['POST'])
def update_alert_rule(rule_id):
    session = Session()
    try:
        rule = session.query(AlertRule).get(rule_id)
        if not rule:
            flash('告警规则不存在')
            return redirect(url_for('system.settings'))
        
        # 获取表单数据
        threshold = request.form.get('threshold', type=float)
        recovery_threshold = request.form.get('recovery_threshold', type=float)
        duration = request.form.get('duration', type=int)
        is_enabled = request.form.get('is_enabled') == 'on'
        
        # 更新规则
        rule.threshold = threshold
        rule.recovery_threshold = recovery_threshold
        rule.duration = duration
        rule.is_enabled = is_enabled
        
        session.commit()
        flash('告警规则更新成功')
        return redirect(url_for('system.settings'))
    finally:
        session.close()
