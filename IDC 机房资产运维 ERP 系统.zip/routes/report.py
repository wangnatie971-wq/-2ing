from flask import Blueprint, render_template, jsonify, request, send_file
from flask_login import login_required
from models.models import Cabinet, Asset, MonitorData, WorkOrder
from datetime import datetime, timedelta
import pandas as pd
import io
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('report', __name__)


@bp.route('/report/capacity')
@login_required
def capacity_report():
    session = Session()
    try:
        # 计算仪表盘卡片数据
        dashboard_data = calculate_dashboard_data()
        
        # 获取机柜容量数据
        cabinet_data = get_cabinet_capacity()
        
        # 获取资源趋势数据
        resource_trend = get_resource_trend()
        
        # 获取扩容建议
        expansion_suggestions = get_expansion_suggestions()
        
        return render_template('report/capacity.html',
                               dashboard_data=dashboard_data,
                               cabinet_data=cabinet_data,
                               resource_trend=resource_trend,
                               expansion_suggestions=expansion_suggestions)
    finally:
        session.close()


@bp.route('/report/export/assets')
@login_required
def export_assets_report():
    session = Session()
    try:
        # 导出资产清单报表
        assets = session.query(Asset).all()
        
        # 创建DataFrame
        data = []
        for asset in assets:
            data.append({
                '资产编号': asset.asset_no,
                '设备名称': asset.name,
                '设备类型': asset.type,
                '型号': asset.model,
                'SN': asset.sn,
                'IP地址': asset.ip_address,
                '机柜': asset.cabinet_id,
                'U位': asset.rack_start_u,
                '状态': asset.status,
                '购买日期': asset.purchase_date.strftime('%Y-%m-%d') if asset.purchase_date else '',
                '创建时间': asset.created_at.strftime('%Y-%m-%d %H:%M:%S')
            })
        
        df = pd.DataFrame(data)
        
        # 导出Excel
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='资产清单', index=False)
        output.seek(0)
        
        return send_file(output, attachment_filename='资产清单报表.xlsx', as_attachment=True)
    finally:
        session.close()


@bp.route('/report/export/workorders', methods=['GET', 'POST'])
@login_required
def export_workorders_report():
    session = Session()
    try:
        if request.method == 'POST':
            # 获取日期范围
            start_date = request.form.get('start_date')
            end_date = request.form.get('end_date')
            
            # 查询工单
            query = session.query(WorkOrder)
            if start_date:
                query = query.filter(WorkOrder.created_at >= datetime.strptime(start_date, '%Y-%m-%d'))
            if end_date:
                query = query.filter(WorkOrder.created_at <= datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1))
            
            workorders = query.all()
            
            # 创建DataFrame
            data = []
            for order in workorders:
                data.append({
                    '工单编号': order.id,
                    '标题': order.title,
                    '类型': order.type,
                    '优先级': order.priority,
                    '状态': order.status,
                    '资产名称': order.asset_name,
                    '创建人': order.creator_id,
                    '处理人': order.assignee_id,
                    '创建时间': order.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                    '更新时间': order.updated_at.strftime('%Y-%m-%d %H:%M:%S') if order.updated_at else ''
                })
            
            df = pd.DataFrame(data)
            
            # 导出Excel
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='工单统计', index=False)
            output.seek(0)
            
            return send_file(output, attachment_filename='工单统计报表.xlsx', as_attachment=True)
        
        return render_template('report/export_workorders.html')
    finally:
        session.close()


def calculate_dashboard_data():
    session = Session()
    try:
        # 计算机柜使用率
        cabinets = session.query(Cabinet).all()
        total_u = 0
        used_u = 0
        
        for cabinet in cabinets:
            total_u += cabinet.rack_units
            # 计算该机柜已使用的U位
            assets = session.query(Asset).filter_by(cabinet_id=cabinet.id).all()
            for asset in assets:
                if asset.rack_start_u and asset.rack_height:
                    used_u += asset.rack_height
        
        cabinet_usage = (used_u / total_u * 100) if total_u > 0 else 0
        
        # 计算平均CPU使用率
        # 获取所有设备的最新CPU使用率
        cpu_usages = []
        assets = session.query(Asset).filter_by(status='online').all()
        for asset in assets:
            latest_data = session.query(MonitorData).filter_by(asset_id=asset.id).order_by(MonitorData.collected_at.desc()).first()
            if latest_data:
                cpu_usages.append(latest_data.cpu_usage)
        
        avg_cpu = sum(cpu_usages) / len(cpu_usages) if cpu_usages else 0
        
        # 计算平均内存使用率
        mem_usages = []
        for asset in assets:
            latest_data = session.query(MonitorData).filter_by(asset_id=asset.id).order_by(MonitorData.collected_at.desc()).first()
            if latest_data:
                mem_usages.append(latest_data.mem_usage)
        
        avg_mem = sum(mem_usages) / len(mem_usages) if mem_usages else 0
        
        # 计算告警设备占比
        total_devices = session.query(Asset).count()
        alert_devices = session.query(Asset).join(MonitorData).filter(
            MonitorData.cpu_usage > 90 |
            MonitorData.mem_usage > 85 |
            MonitorData.disk_usage > 90 |
            MonitorData.ping_status == 0
        ).distinct().count()
        
        alert_ratio = (alert_devices / total_devices * 100) if total_devices > 0 else 0
        
        return {
            'cabinet_usage': round(cabinet_usage, 2),
            'avg_cpu': round(avg_cpu, 2),
            'avg_mem': round(avg_mem, 2),
            'alert_ratio': round(alert_ratio, 2)
        }
    finally:
        session.close()

def get_cabinet_capacity():
    session = Session()
    try:
        # 获取机柜容量数据
        cabinets = session.query(Cabinet).all()
        cabinet_data = []
        
        for cabinet in cabinets:
            total_u = cabinet.rack_units
            # 计算该机柜已使用的U位
            used_u = 0
            assets = session.query(Asset).filter_by(cabinet_id=cabinet.id).all()
            for asset in assets:
                if asset.rack_start_u and asset.rack_height:
                    used_u += asset.rack_height
            
            usage_ratio = (used_u / total_u * 100) if total_u > 0 else 0
            
            cabinet_data.append({
                'name': cabinet.name,
                'total_u': total_u,
                'used_u': used_u,
                'usage_ratio': round(usage_ratio, 2)
            })
        
        return cabinet_data
    finally:
        session.close()

def get_resource_trend():
    session = Session()
    try:
        # 获取最近30天的资源趋势数据
        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=30)
        
        # 生成日期列表
        date_list = []
        current_date = start_date
        while current_date <= end_date:
            date_list.append(current_date.strftime('%Y-%m-%d'))
            current_date += timedelta(days=1)
        
        # 计算每天的平均资源使用率
        cpu_trend = []
        mem_trend = []
        disk_trend = []
        
        for date_str in date_list:
            date = datetime.strptime(date_str, '%Y-%m-%d')
            next_date = date + timedelta(days=1)
            
            # 获取当天的监控数据
            monitor_data = session.query(MonitorData).filter(
                MonitorData.collected_at >= date,
                MonitorData.collected_at < next_date
            ).all()
            
            if monitor_data:
                # 计算当天的平均使用率
                cpu_sum = sum(data.cpu_usage for data in monitor_data)
                mem_sum = sum(data.mem_usage for data in monitor_data)
                disk_sum = sum(data.disk_usage for data in monitor_data)
                
                cpu_trend.append(round(cpu_sum / len(monitor_data), 2))
                mem_trend.append(round(mem_sum / len(monitor_data), 2))
                disk_trend.append(round(disk_sum / len(monitor_data), 2))
            else:
                cpu_trend.append(0)
                mem_trend.append(0)
                disk_trend.append(0)
        
        return {
            'dates': date_list,
            'cpu_trend': cpu_trend,
            'mem_trend': mem_trend,
            'disk_trend': disk_trend
        }
    finally:
        session.close()

def get_expansion_suggestions():
    session = Session()
    try:
        # 获取扩容建议
        suggestions = []
        
        # 检查机柜使用率
        cabinets = session.query(Cabinet).all()
        for cabinet in cabinets:
            total_u = cabinet.rack_units
            used_u = 0
            assets = session.query(Asset).filter_by(cabinet_id=cabinet.id).all()
            for asset in assets:
                if asset.rack_start_u and asset.rack_height:
                    used_u += asset.rack_height
            
            usage_ratio = (used_u / total_u * 100) if total_u > 0 else 0
            if usage_ratio > 80:
                suggestions.append({
                    'type': '机柜',
                    'name': cabinet.name,
                    'current_usage': f'{round(usage_ratio, 2)}%',
                    'suggestion': '建议扩容'
                })
        
        # 检查磁盘使用率
        assets = session.query(Asset).filter_by(status='online').all()
        for asset in assets:
            latest_data = session.query(MonitorData).filter_by(asset_id=asset.id).order_by(MonitorData.collected_at.desc()).first()
            if latest_data and latest_data.disk_usage > 85:
                suggestions.append({
                    'type': '设备',
                    'name': asset.name,
                    'current_usage': f'{latest_data.disk_usage}%',
                    'suggestion': '建议扩容磁盘'
                })
        
        return suggestions
    finally:
        session.close()
