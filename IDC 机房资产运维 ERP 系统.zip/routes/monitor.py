from flask import Blueprint, render_template, jsonify, request, redirect, url_for, flash
from flask_login import login_required
from models.models import Asset, MonitorData, AlertRule, AlertRecord, WorkOrder, WorkOrderLog
from datetime import datetime, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('monitor', __name__)


@bp.route('/monitor/overview')
@login_required
def monitor_overview():
    session = Session()
    try:
        # 获取所有设备
        assets = session.query(Asset).all()
        
        # 获取设备在线率数据
        online_count = session.query(Asset).filter_by(status='online').count()
        offline_count = session.query(Asset).filter_by(status='offline').count()
        total_count = online_count + offline_count
        
        # 获取资源使用率TOP10
        # 这里简化处理，实际应该查询最新的监控数据
        top_assets = session.query(Asset).limit(10).all()
        
        return render_template('monitor/overview.html', 
                               assets=assets,
                               online_count=online_count,
                               offline_count=offline_count,
                               total_count=total_count,
                               top_assets=top_assets)
    finally:
        session.close()


@bp.route('/monitor/data/<int:asset_id>')
def get_asset_data(asset_id):
    session = Session()
    try:
        # 获取指定设备最近1小时的监控数据
        one_hour_ago = datetime.utcnow() - timedelta(hours=1)
        
        monitor_data = session.query(MonitorData).filter(
            MonitorData.asset_id == asset_id,
            MonitorData.collected_at >= one_hour_ago
        ).order_by(MonitorData.collected_at).all()
        
        # 格式化数据
        timestamps = []
        cpu_data = []
        mem_data = []
        disk_data = []
        
        for data in monitor_data:
            timestamps.append(data.collected_at.strftime('%H:%M:%S'))
            cpu_data.append(data.cpu_usage)
            mem_data.append(data.mem_usage)
            disk_data.append(data.disk_usage)
        
        return jsonify({
            'timestamps': timestamps,
            'cpu_data': cpu_data,
            'mem_data': mem_data,
            'disk_data': disk_data
        })
    finally:
        session.close()


@bp.route('/monitor/online-rate')
def get_online_rate():
    session = Session()
    try:
        # 获取设备在线率数据
        online_count = session.query(Asset).filter_by(status='online').count()
        offline_count = session.query(Asset).filter_by(status='offline').count()
        total_count = online_count + offline_count
        
        return jsonify({
            'online_count': online_count,
            'offline_count': offline_count,
            'total_count': total_count
        })
    finally:
        session.close()


@bp.route('/monitor/top-usage')
def get_top_usage():
    session = Session()
    try:
        # 获取资源使用率TOP10
        # 这里简化处理，实际应该查询最新的监控数据并排序
        top_assets = session.query(Asset).limit(10).all()
        
        asset_names = []
        cpu_usages = []
        mem_usages = []
        disk_usages = []
        
        for asset in top_assets:
            # 获取最新的监控数据
            latest_data = session.query(MonitorData).filter_by(asset_id=asset.id).order_by(MonitorData.collected_at.desc()).first()
            
            asset_names.append(asset.name)
            if latest_data:
                cpu_usages.append(latest_data.cpu_usage)
                mem_usages.append(latest_data.mem_usage)
                disk_usages.append(latest_data.disk_usage)
            else:
                cpu_usages.append(0)
                mem_usages.append(0)
                disk_usages.append(0)
        
        return jsonify({
            'asset_names': asset_names,
            'cpu_usages': cpu_usages,
            'mem_usages': mem_usages,
            'disk_usages': disk_usages
        })
    finally:
        session.close()


@bp.route('/monitor/rules')
@login_required
def alert_rules():
    session = Session()
    try:
        # 检查是否需要初始化默认规则
        init_default_rules()
        
        # 获取所有告警规则
        rules = session.query(AlertRule).all()
        
        return render_template('monitor/rules.html', rules=rules)
    finally:
        session.close()


@bp.route('/monitor/rule/add', methods=['GET', 'POST'])
@login_required
def add_alert_rule():
    session = Session()
    try:
        if request.method == 'POST':
            # 获取表单数据
            name = request.form['name']
            metric = request.form['metric']
            condition = request.form['condition']
            threshold = int(request.form['threshold'])
            level = request.form['level']
            enabled = request.form.get('enabled', False) == 'on'
            
            # 创建告警规则
            new_rule = AlertRule(
                name=name,
                metric=metric,
                condition=condition,
                threshold=threshold,
                level=level,
                enabled=enabled
            )
            
            session.add(new_rule)
            session.commit()
            
            flash('告警规则添加成功')
            return redirect(url_for('monitor.alert_rules'))
        
        return render_template('monitor/add_rule.html')
    finally:
        session.close()


@bp.route('/monitor/rule/edit/<int:rule_id>', methods=['GET', 'POST'])
@login_required
def edit_alert_rule(rule_id):
    session = Session()
    try:
        rule = session.query(AlertRule).get(rule_id)
        if not rule:
            flash('告警规则不存在')
            return redirect(url_for('monitor.alert_rules'))
        
        if request.method == 'POST':
            # 更新告警规则
            rule.name = request.form['name']
            rule.metric = request.form['metric']
            rule.condition = request.form['condition']
            rule.threshold = int(request.form['threshold'])
            rule.level = request.form['level']
            rule.enabled = request.form.get('enabled', False) == 'on'
            
            session.commit()
            
            flash('告警规则更新成功')
            return redirect(url_for('monitor.alert_rules'))
        
        return render_template('monitor/edit_rule.html', rule=rule)
    finally:
        session.close()


@bp.route('/monitor/rule/toggle/<int:rule_id>')
@login_required
def toggle_alert_rule(rule_id):
    session = Session()
    try:
        rule = session.query(AlertRule).get(rule_id)
        if not rule:
            flash('告警规则不存在')
            return redirect(url_for('monitor.alert_rules'))
        
        # 切换启用状态
        rule.enabled = not rule.enabled
        session.commit()
        
        flash('告警规则状态已更新')
        return redirect(url_for('monitor.alert_rules'))
    finally:
        session.close()


@bp.route('/monitor/alerts')
@login_required
def alert_list():
    session = Session()
    try:
        # 获取活跃告警
        active_alerts = session.query(AlertRecord).filter(
            AlertRecord.status.in_(['active', 'acknowledged'])
        ).order_by(
            AlertRecord.level == 'critical',
            AlertRecord.level == 'warning',
            AlertRecord.level == 'info',
            AlertRecord.created_at.desc()
        ).all()
        
        # 获取历史告警
        history_alerts = session.query(AlertRecord).filter_by(status='resolved').order_by(AlertRecord.created_at.desc()).all()
        
        return render_template('monitor/alerts.html', active_alerts=active_alerts, history_alerts=history_alerts)
    finally:
        session.close()


@bp.route('/monitor/alert/acknowledge/<int:alert_id>')
@login_required
def acknowledge_alert(alert_id):
    session = Session()
    try:
        alert = session.query(AlertRecord).get(alert_id)
        if not alert:
            flash('告警记录不存在')
            return redirect(url_for('monitor.alert_list'))
        
        # 更新告警状态
        alert.status = 'acknowledged'
        session.commit()
        
        flash('告警已确认')
        return redirect(url_for('monitor.alert_list'))
    finally:
        session.close()


@bp.route('/monitor/alert/resolve/<int:alert_id>')
@login_required
def resolve_alert(alert_id):
    session = Session()
    try:
        alert = session.query(AlertRecord).get(alert_id)
        if not alert:
            flash('告警记录不存在')
            return redirect(url_for('monitor.alert_list'))
        
        # 更新告警状态
        alert.status = 'resolved'
        alert.resolved_at = datetime.utcnow()
        session.commit()
        
        flash('告警已解决')
        return redirect(url_for('monitor.alert_list'))
    finally:
        session.close()


@bp.route('/monitor/alerts/count')
def get_alert_count():
    session = Session()
    try:
        # 获取活跃的严重告警数量
        critical_count = session.query(AlertRecord).filter_by(level='critical', status='active').count()
        
        return jsonify({
            'critical_count': critical_count
        })
    finally:
        session.close()


def init_default_rules():
    session = Session()
    try:
        # 检查是否已有告警规则
        existing_rules = session.query(AlertRule).count()
        if existing_rules > 0:
            return
        
        # 预置默认规则
        default_rules = [
            {'name': 'CPU使用率过高', 'metric': 'cpu', 'condition': 'gt', 'threshold': 90, 'level': 'critical', 'enabled': True},
            {'name': '内存使用率过高', 'metric': 'mem', 'condition': 'gt', 'threshold': 85, 'level': 'warning', 'enabled': True},
            {'name': '磁盘使用率过高', 'metric': 'disk', 'condition': 'gt', 'threshold': 90, 'level': 'critical', 'enabled': True},
            {'name': '设备离线', 'metric': 'ping', 'condition': 'eq', 'threshold': 0, 'level': 'critical', 'enabled': True}
        ]
        
        for rule_data in default_rules:
            rule = AlertRule(**rule_data)
            session.add(rule)
        
        session.commit()
        print('默认告警规则已初始化')
    finally:
        session.close()


def create_workorder_for_critical_alert(asset_id, asset_name, message):
    session = Session()
    try:
        # 为严重告警创建工单
        new_order = WorkOrder(
            title=f'【严重告警】{asset_name}',
            type='fault',
            priority='critical',
            status='pending',
            asset_id=asset_id,
            asset_name=asset_name,
            creator_id=1,  # 默认创建人
            description=message
        )
        
        session.add(new_order)
        session.commit()
        
        # 记录操作日志
        log = WorkOrderLog(
            order_id=new_order.id,
            action='创建工单',
            operator_id=1,
            content=f'由严重告警自动创建工单：{message}'
        )
        session.add(log)
        session.commit()
        
        print(f'为设备 {asset_name} 创建了故障工单')
    finally:
        session.close()

