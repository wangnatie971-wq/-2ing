from flask import Blueprint, render_template, request
from flask_login import login_required
from models.models import OperationLog, Asset, WorkOrder, IPAddress
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('dashboard', __name__)

@bp.route('/dashboard')
@login_required
def index():
    session = Session()
    try:
        # 模拟数据
        stats = {
            'total_assets': 128,
            'online_devices': 115,
            'active_alerts': 8,
            'pending_tickets': 12
        }
        
        # 设备类型分布数据
        device_types = {
            'labels': ['服务器', '网络设备', '存储设备', '安全设备', '其他'],
            'data': [65, 30, 15, 10, 5]
        }
        
        # 最近7天工单趋势数据
        ticket_trend = {
            'labels': ['4/7', '4/8', '4/9', '4/10', '4/11', '4/12', '4/13'],
            'data': [5, 8, 3, 12, 7, 9, 12]
        }
        
        # 获取最近10条操作日志
        recent_operations = session.query(OperationLog).order_by(OperationLog.created_at.desc()).limit(10).all()
        
        return render_template('dashboard/index.html', stats=stats, device_types=device_types, ticket_trend=ticket_trend, recent_operations=recent_operations)
    finally:
        session.close()

@bp.route('/dashboard/search')
@login_required
def search():
    session = Session()
    try:
        query = request.args.get('q', '')
        results = {
            'assets': [],
            'workorders': [],
            'ip_addresses': []
        }
        
        if query:
            # 搜索资产
            assets = session.query(Asset).filter(
                (Asset.name.like(f'%{query}%')) |
                (Asset.asset_no.like(f'%{query}%')) |
                (Asset.ip_address.like(f'%{query}%')) |
                (Asset.sn.like(f'%{query}%'))
            ).limit(10).all()
            results['assets'] = assets
            
            # 搜索工单
            workorders = session.query(WorkOrder).filter(
                (WorkOrder.title.like(f'%{query}%')) |
                (WorkOrder.id.like(f'%{query}%')) |
                (WorkOrder.asset_name.like(f'%{query}%'))
            ).limit(10).all()
            results['workorders'] = workorders
            
            # 搜索IP地址
            ip_addresses = session.query(IPAddress).filter(
                IPAddress.address.like(f'%{query}%')
            ).limit(10).all()
            results['ip_addresses'] = ip_addresses
        
        return render_template('dashboard/search.html', query=query, results=results)
    finally:
        session.close()
