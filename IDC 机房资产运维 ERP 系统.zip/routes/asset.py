from flask import Blueprint, render_template, request, redirect, url_for, flash, send_file
from flask_login import login_required, current_user
from models.models import Asset, Cabinet, AssetLog
import csv
from io import StringIO, BytesIO
from flask import make_response
import re
from datetime import datetime
import openpyxl
from utils.permission import permission_required
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('asset', __name__)

@bp.route('/asset/list')
@login_required
@permission_required('read_only')
def list_assets():
    session = Session()
    # 获取搜索参数
    name = request.args.get('name', '')
    asset_type = request.args.get('type', '')
    status = request.args.get('status', '')
    room = request.args.get('room', '')
    
    # 构建查询
    query = session.query(Asset)
    
    # 应用筛选条件
    if name:
        query = query.filter(Asset.name.like(f'%{name}%'))
    if asset_type:
        query = query.filter(Asset.type == asset_type)
    if status:
        query = query.filter(Asset.status == status)
    if room:
        # 通过机柜关联查询机房
        query = query.join(Cabinet).filter(Cabinet.room.like(f'%{room}%'))
    
    # 分页
    page = request.args.get('page', 1, type=int)
    per_page = 15
    offset = (page - 1) * per_page
    
    # 获取总记录数
    total = query.count()
    # 获取当前页的数据
    assets = query.offset(offset).limit(per_page).all()
    
    # 模拟 pagination 对象，用于模板
    class Pagination:
        def __init__(self, page, per_page, total, items):
            self.page = page
            self.per_page = per_page
            self.total = total
            self.items = items
            self.pages = (total + per_page - 1) // per_page
            
        @property
        def has_prev(self):
            return self.page > 1
            
        @property
        def has_next(self):
            return self.page < self.pages
            
        def prev_num(self):
            return self.page - 1 if self.has_prev else None
            
        def next_num(self):
            return self.page + 1 if self.has_next else None
    
    pagination = Pagination(page, per_page, total, assets)
    
    # 获取所有机柜信息，用于展示
    cabinets = session.query(Cabinet).all()
    cabinet_dict = {cabinet.id: cabinet for cabinet in cabinets}
    
    # 资产类型和状态选项
    asset_types = ['server', 'switch', 'router', 'firewall', 'ups']
    asset_statuses = ['online', 'offline', 'idle', 'maintenance']
    
    try:
        return render_template('asset/list.html', 
                             assets=assets, 
                             pagination=pagination, 
                             name=name, 
                             type=asset_type, 
                             status=status, 
                             room=room, 
                             asset_types=asset_types, 
                             asset_statuses=asset_statuses, 
                             cabinet_dict=cabinet_dict)
    finally:
        session.close()

@bp.route('/asset/detail/<int:asset_id>')
@login_required
@permission_required('read_only')
def asset_detail(asset_id):
    session = Session()
    try:
        asset = session.query(Asset).get(asset_id)
        if not asset:
            flash('资产不存在')
            return redirect(url_for('asset.list_assets'))
        
        # 获取机柜信息
        cabinet = None
        if asset.cabinet_id:
            cabinet = session.query(Cabinet).get(asset.cabinet_id)
        
        # 获取操作日志
        logs = session.query(AssetLog).filter_by(asset_id=asset_id).order_by(AssetLog.create_time.desc()).all()
        
        # 模拟关联工单数据
        # 实际项目中应该从工单表中查询
        tickets = []
        
        return render_template('asset/detail.html', asset=asset, cabinet=cabinet, logs=logs, tickets=tickets)
    finally:
        session.close()

@bp.route('/asset/edit/<int:asset_id>', methods=['GET', 'POST'])
@login_required
@permission_required('asset_management')
def edit_asset(asset_id):
    session = Session()
    try:
        asset = session.query(Asset).get(asset_id)
        if not asset:
            flash('资产不存在')
            return redirect(url_for('asset.list_assets'))
        
        if request.method == 'POST':
            # 获取表单数据
            asset_no = request.form['asset_no']
            name = request.form['name']
            asset_type = request.form['type']
            brand = request.form['brand']
            model = request.form['model']
            sn = request.form['sn']
            cabinet_id = request.form['cabinet_id'] or None
            rack_start_u = request.form['rack_start_u'] or None
            status = request.form['status']
            ip_address = request.form['ip_address']
            os = request.form['os']
            cpu = request.form['cpu']
            memory = request.form['memory']
            disk = request.form['disk']
            purchase_date = request.form['purchase_date'] or None
            warranty_end = request.form['warranty_end'] or None
            
            # 表单校验
            # 1. 资产编号唯一性校验（排除当前资产）
            existing_asset = session.query(Asset).filter(Asset.asset_no == asset_no, Asset.id != asset_id).first()
            if existing_asset:
                flash('资产编号已存在')
                return redirect(url_for('asset.edit_asset', asset_id=asset_id))
            
            # 2. SN唯一性校验（如果填写了SN，排除当前资产）
            if sn:
                existing_sn = session.query(Asset).filter(Asset.sn == sn, Asset.id != asset_id).first()
                if existing_sn:
                    flash('序列号已存在')
                    return redirect(url_for('asset.edit_asset', asset_id=asset_id))
            
            # 3. IP地址格式校验（如果填写了IP）
            if ip_address:
                ip_regex = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
                if not re.match(ip_regex, ip_address):
                    flash('IP地址格式不正确')
                    return redirect(url_for('asset.edit_asset', asset_id=asset_id))
            
            # 4. 日期格式转换
            if purchase_date:
                purchase_date = datetime.strptime(purchase_date, '%Y-%m-%d')
            if warranty_end:
                warranty_end = datetime.strptime(warranty_end, '%Y-%m-%d')
            
            # 保存修改
            asset.asset_no = asset_no
            asset.name = name
            asset.type = asset_type
            asset.brand = brand
            asset.model = model
            asset.sn = sn
            asset.cabinet_id = cabinet_id
            asset.rack_start_u = rack_start_u
            asset.status = status
            asset.ip_address = ip_address
            asset.os = os
            asset.cpu = cpu
            asset.memory = memory
            asset.disk = disk
            asset.purchase_date = purchase_date
            asset.warranty_end = warranty_end
            
            session.commit()
            
            # 记录操作日志
            operator = current_user.username
            log = AssetLog(
                asset_id=asset.id,
                action='编辑资产',
                operator=operator,
                detail=f'编辑资产：{name}（{asset_no}）'
            )
            session.add(log)
            session.commit()
            
            # 显示成功提示并跳转
            flash('资产信息更新成功')
            return redirect(url_for('asset.list_assets'))
        
        # 获取所有机柜信息
        cabinets = session.query(Cabinet).all()
        
        return render_template('asset/edit.html', asset=asset, cabinets=cabinets)
    finally:
        session.close()

@bp.route('/asset/delete/<int:asset_id>')
@login_required
@permission_required('asset_management')
def delete_asset(asset_id):
    session = Session()
    try:
        asset = session.query(Asset).get(asset_id)
        if asset:
            session.delete(asset)
            session.commit()
            flash('资产删除成功')
        else:
            flash('资产不存在')
        return redirect(url_for('asset.list_assets'))
    finally:
        session.close()

@bp.route('/asset/cabinet')
@login_required
@permission_required('read_only')
def view_cabinets():
    session = Session()
    try:
        # 获取所有机柜
        cabinets = session.query(Cabinet).all()
        
        # 获取所有资产，按机柜和U位分组
        assets = session.query(Asset).filter(Asset.cabinet_id.isnot(None), Asset.rack_start_u.isnot(None)).all()
        
        # 构建机柜资产映射
        cabinet_assets = {}
        for asset in assets:
            if asset.cabinet_id not in cabinet_assets:
                cabinet_assets[asset.cabinet_id] = {}
            cabinet_assets[asset.cabinet_id][asset.rack_start_u] = asset
        
        return render_template('asset/cabinet.html', cabinets=cabinets, cabinet_assets=cabinet_assets)
    finally:
        session.close()

@bp.route('/asset/add', methods=['GET', 'POST'])
@login_required
@permission_required('asset_management')
def add_asset():
    session = Session()
    try:
        if request.method == 'POST':
            # 获取表单数据
            asset_no = request.form['asset_no']
            name = request.form['name']
            asset_type = request.form['type']
            brand = request.form['brand']
            model = request.form['model']
            sn = request.form['sn']
            cabinet_id = request.form['cabinet_id'] or None
            rack_start_u = request.form['rack_start_u'] or None
            status = request.form['status']
            ip_address = request.form['ip_address']
            os = request.form['os']
            cpu = request.form['cpu']
            memory = request.form['memory']
            disk = request.form['disk']
            purchase_date = request.form['purchase_date'] or None
            warranty_end = request.form['warranty_end'] or None
            
            # 表单校验
            # 1. 资产编号唯一性校验
            existing_asset = session.query(Asset).filter_by(asset_no=asset_no).first()
            if existing_asset:
                flash('资产编号已存在')
                return redirect(url_for('asset.add_asset'))
            
            # 2. SN唯一性校验（如果填写了SN）
            if sn:
                existing_sn = session.query(Asset).filter_by(sn=sn).first()
                if existing_sn:
                    flash('序列号已存在')
                    return redirect(url_for('asset.add_asset'))
            
            # 3. IP地址格式校验（如果填写了IP）
            if ip_address:
                ip_regex = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
                if not re.match(ip_regex, ip_address):
                    flash('IP地址格式不正确')
                    return redirect(url_for('asset.add_asset'))
            
            # 4. 日期格式转换
            if purchase_date:
                purchase_date = datetime.strptime(purchase_date, '%Y-%m-%d')
            if warranty_end:
                warranty_end = datetime.strptime(warranty_end, '%Y-%m-%d')
            
            # 创建新资产
            new_asset = Asset(
                asset_no=asset_no,
                name=name,
                type=asset_type,
                brand=brand,
                model=model,
                sn=sn,
                cabinet_id=cabinet_id,
                rack_start_u=rack_start_u,
                status=status,
                ip_address=ip_address,
                os=os,
                cpu=cpu,
                memory=memory,
                disk=disk,
                purchase_date=purchase_date,
                warranty_end=warranty_end
            )
            
            session.add(new_asset)
            session.commit()
            
            # 记录操作日志
            operator = current_user.username
            log = AssetLog(
                asset_id=new_asset.id,
                action='新增资产',
                operator=operator,
                detail=f'新增资产：{name}（{asset_no}）'
            )
            session.add(log)
            session.commit()
            
            # 显示成功提示并跳转
            flash('资产新增成功')
            return redirect(url_for('asset.list_assets'))
        
        # GET请求，获取所有机柜信息
        cabinets = session.query(Cabinet).all()
        return render_template('asset/add.html', cabinets=cabinets)
    finally:
        session.close()

@bp.route('/asset/export')
@login_required
@permission_required('read_only')
def export_assets():
    session = Session()
    try:
        # 获取搜索参数
        name = request.args.get('name', '')
        asset_type = request.args.get('type', '')
        status = request.args.get('status', '')
        room = request.args.get('room', '')
        
        # 构建查询
        query = session.query(Asset)
        
        # 应用筛选条件
        if name:
            query = query.filter(Asset.name.like(f'%{name}%'))
        if asset_type:
            query = query.filter(Asset.type == asset_type)
        if status:
            query = query.filter(Asset.status == status)
        if room:
            query = query.join(Cabinet).filter(Cabinet.room.like(f'%{room}%'))
        
        assets = query.all()
        
        # 创建CSV文件
        output = StringIO()
        writer = csv.writer(output)
        
        # 写入表头
        writer.writerow(['资产编号', '资产名称', '类型', '品牌', '型号', '序列号', '机柜', '起始U位', '状态', 'IP地址', '操作系统', 'CPU', '内存', '磁盘', '购买日期', ' warranty结束日期'])
        
        # 写入数据
        for asset in assets:
            cabinet_name = ''
            if asset.cabinet_id:
                cabinet = session.query(Cabinet).get(asset.cabinet_id)
                if cabinet:
                    cabinet_name = cabinet.name
            
            writer.writerow([
                asset.asset_no,
                asset.name,
                asset.type,
                asset.brand,
                asset.model,
                asset.sn,
                cabinet_name,
                asset.rack_start_u,
                asset.status,
                asset.ip_address,
                asset.os,
                asset.cpu,
                asset.memory,
                asset.disk,
                asset.purchase_date.strftime('%Y-%m-%d') if asset.purchase_date else '',
                asset.warranty_end.strftime('%Y-%m-%d') if asset.warranty_end else ''
            ])
        
        output.seek(0)
        
        # 创建响应
        response = make_response(output.getvalue())
        response.headers['Content-Disposition'] = 'attachment; filename=assets.csv'
        response.headers['Content-Type'] = 'text/csv'
        
        return response
    finally:
        session.close()

@bp.route('/asset/import/template')
@login_required
@permission_required('asset_management')
def download_import_template():
    # 创建Excel模板文件
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '资产导入模板'
    
    # 写入表头
    headers = ['资产编号', '资产名称', '类型', '品牌', '型号', '序列号', '机柜名称', '起始U位', '状态', 'IP地址', '操作系统', 'CPU', '内存', '磁盘', '购买日期', ' warranty结束日期']
    ws.append(headers)
    
    # 写入示例数据
    example = ['SVR-001', '测试服务器', 'server', 'Dell', 'R740', 'SN123456', 'A01', '1', 'online', '192.168.1.100', 'Ubuntu 20.04', 'Intel Xeon 8C', '32GB', '2TB SSD', '2023-01-01', '2026-01-01']
    ws.append(example)
    
    # 保存到内存
    output = BytesIO()
    wb.save(output)
    output.seek(0)
    
    # 创建响应
    response = make_response(output.getvalue())
    response.headers['Content-Disposition'] = 'attachment; filename=asset_import_template.xlsx'
    response.headers['Content-Type'] = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    
    return response

@bp.route('/asset/import', methods=['GET', 'POST'])
@login_required
@permission_required('asset_management')
def import_assets():
    session = Session()
    try:
        if request.method == 'POST':
            # 检查是否有文件上传
            if 'file' not in request.files:
                flash('请选择Excel文件')
                return redirect(url_for('asset.import_assets'))
            
            file = request.files['file']
            if file.filename == '':
                flash('请选择Excel文件')
                return redirect(url_for('asset.import_assets'))
            
            # 检查文件类型
            if not file.filename.endswith('.xlsx'):
                flash('请上传Excel文件（.xlsx）')
                return redirect(url_for('asset.import_assets'))
            
            try:
                # 读取Excel文件
                wb = openpyxl.load_workbook(file)
                ws = wb.active
                
                # 获取机柜映射
                cabinets = session.query(Cabinet).all()
                cabinet_map = {cabinet.name: cabinet.id for cabinet in cabinets}
                
                # 跳过表头，从第二行开始读取
                success_count = 0
                error_count = 0
                errors = []
                
                for row in ws.iter_rows(min_row=2, values_only=True):
                    try:
                        asset_no, name, asset_type, brand, model, sn, cabinet_name, rack_start_u, status, ip_address, os, cpu, memory, disk, purchase_date, warranty_end = row
                        
                        # 表单校验
                        # 1. 资产编号唯一性校验
                        existing_asset = session.query(Asset).filter_by(asset_no=asset_no).first()
                        if existing_asset:
                            error_count += 1
                            errors.append(f'资产编号 {asset_no} 已存在')
                            continue
                        
                        # 2. SN唯一性校验（如果填写了SN）
                        if sn:
                            existing_sn = session.query(Asset).filter_by(sn=sn).first()
                            if existing_sn:
                                error_count += 1
                                errors.append(f'序列号 {sn} 已存在')
                                continue
                        
                        # 3. IP地址格式校验（如果填写了IP）
                        if ip_address:
                            ip_regex = r'^((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
                            if not re.match(ip_regex, ip_address):
                                error_count += 1
                                errors.append(f'IP地址 {ip_address} 格式不正确')
                                continue
                        
                        # 4. 机柜名称转换为机柜ID
                        cabinet_id = None
                        if cabinet_name:
                            if cabinet_name not in cabinet_map:
                                error_count += 1
                                errors.append(f'机柜 {cabinet_name} 不存在')
                                continue
                            cabinet_id = cabinet_map[cabinet_name]
                        
                        # 5. 日期格式转换
                        if purchase_date and isinstance(purchase_date, str):
                            purchase_date = datetime.strptime(purchase_date, '%Y-%m-%d')
                        if warranty_end and isinstance(warranty_end, str):
                            warranty_end = datetime.strptime(warranty_end, '%Y-%m-%d')
                        
                        # 创建新资产
                        new_asset = Asset(
                            asset_no=asset_no,
                            name=name,
                            type=asset_type,
                            brand=brand,
                            model=model,
                            sn=sn,
                            cabinet_id=cabinet_id,
                            rack_start_u=rack_start_u,
                            status=status,
                            ip_address=ip_address,
                            os=os,
                            cpu=cpu,
                            memory=memory,
                            disk=disk,
                            purchase_date=purchase_date,
                            warranty_end=warranty_end
                        )
                        
                        session.add(new_asset)
                        success_count += 1
                        
                    except Exception as e:
                        error_count += 1
                        errors.append(f'第 {row[0]} 行数据错误: {str(e)}')
                
                # 提交事务
                session.commit()
                
                # 记录操作日志
                operator = current_user.username
                log = AssetLog(
                    asset_id=0,  # 批量导入，使用0表示
                    action='批量导入资产',
                    operator=operator,
                    detail=f'成功导入 {success_count} 条资产，失败 {error_count} 条'
                )
                session.add(log)
                session.commit()
                
                # 显示结果
                flash(f'批量导入完成：成功 {success_count} 条，失败 {error_count} 条')
                if errors:
                    for error in errors:
                        flash(error)
                
                return redirect(url_for('asset.list_assets'))
                
            except Exception as e:
                flash(f'导入失败：{str(e)}')
                return redirect(url_for('asset.import_assets'))
        
        return render_template('asset/import.html')
    finally:
        session.close()
