from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, logout_user, login_required
from models.models import User
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    session = Session()
    try:
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            user = session.query(User).filter_by(username=username).first()
            if user and user.check_password(password):
                login_user(user)
                return redirect(url_for('dashboard.index'))
            flash('用户名或密码错误')
        return render_template('auth/login.html')
    finally:
        session.close()

@bp.route('/register', methods=['GET', 'POST'])
def register():
    session = Session()
    try:
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']
            real_name = request.form['real_name']
            role = request.form['role']
            email = request.form['email']
            
            # 检查用户名是否已存在
            existing_user = session.query(User).filter_by(username=username).first()
            if existing_user:
                flash('用户名已存在')
                return redirect(url_for('auth.register'))
            
            # 创建新用户
            new_user = User(
                username=username,
                real_name=real_name,
                role=role,
                email=email
            )
            new_user.set_password(password)
            session.add(new_user)
            session.commit()
            
            flash('注册成功，请登录')
            return redirect(url_for('auth.login'))
        return render_template('auth/register.html')
    finally:
        session.close()

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))
