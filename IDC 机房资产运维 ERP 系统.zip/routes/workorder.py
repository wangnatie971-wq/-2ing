from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from models.models import WorkOrder, WorkOrderLog, Asset, User
from sqlalchemy import func
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime, timedelta

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('workorder', __name__)

# 工单类型选项
workorder_types = ['fault', 'change', 'inspect', 'deploy']

# 工单优先级选项
workorder_priorities = ['critical', 'high', 'medium', 'low']

# 工单状态选项
workorder_statuses = ['pending', 'processing', 'accepted', 'completed', 'closed']

# SLA时间配置（分钟）
sla_times = {
    'critical': 30,
    'high': 120,
    'medium': 240,
    'low': 1440
}


@bp.route('/workorder/list')
@login_required
def list_workorders():
    session = Session()
    try:
        # 获取筛选参数
        type_filter = request.args.get('type', '')
        priority_filter = request.args.get('priority', '')
        status_filter = request.args.get('status', '')
        assignee_filter = request.args.get('assignee', '')
        
        # 构建查询
        query = session.query(WorkOrder)
        
        # 应用筛选条件
        if type_filter:
            query = query.filter(WorkOrder.type == type_filter)
        if priority_filter:
            query = query.filter(WorkOrder.priority == priority_filter)
        if status_filter:
            query = query.filter(WorkOrder.status == status_filter)
        if assignee_filter:
            query = query.filter(WorkOrder.assignee_id == assignee_filter)
        
        # 排序：紧急工单置顶，然后按创建时间倒序
        query = query.order_by(
            WorkOrder.priority == 'critical',
            WorkOrder.priority == 'high',
            WorkOrder.priority == 'medium',
            WorkOrder.priority == 'low',
            WorkOrder.created_at.desc()
        )
        
        # 分页
        page = request.args.get('page', 1, type=int)
        per_page = 10
        offset = (page - 1) * per_page
        
        # 获取总记录数
        total = query.count()
        # 获取当前页的数据
        workorders = query.offset(offset).limit(per_page).all()
        
        # 模拟 pagination 对象，用于模板
        class Pagination:
            def __init__(self, page, per_page, total, items):
                self.page = page
                self.per_page = per_page
                self.total = total
                self.items = items
                self.pages = (total + per_page - 1) // per_page
                
            @property
            def has_prev(self):
                return self.page > 1
                
            @property
            def has_next(self):
                return self.page < self.pages
                
            def prev_num(self):
                return self.page - 1 if self.has_prev else None
                
            def next_num(self):
                return self.page + 1 if self.has_next else None
        
        pagination = Pagination(page, per_page, total, workorders)
        
        # 获取所有用户（用于处理人筛选）
        users = session.query(User).all()
        
        return render_template('workorder/list.html', 
                               workorders=workorders, 
                               pagination=pagination,
                               type_filter=type_filter,
                               priority_filter=priority_filter,
                               status_filter=status_filter,
                               assignee_filter=assignee_filter,
                               workorder_types=workorder_types,
                               workorder_priorities=workorder_priorities,
                               workorder_statuses=workorder_statuses,
                               users=users)
    finally:
        session.close()


@bp.route('/workorder/create', methods=['GET', 'POST'])
@login_required
def create_workorder():
    session = Session()
    try:
        if request.method == 'POST':
            # 获取表单数据
            title = request.form['title']
            type = request.form['type']
            priority = request.form['priority']
            asset_id = request.form['asset_id'] or None
            description = request.form['description']
            
            # 计算SLA截止时间
            sla_minutes = sla_times.get(priority, 1440)  # 默认24小时
            sla_deadline = datetime.utcnow() + timedelta(minutes=sla_minutes)
            
            # 获取资产名称
            asset_name = ''
            if asset_id:
                asset = session.query(Asset).get(asset_id)
                if asset:
                    asset_name = asset.name
            
            # 创建工单
            new_order = WorkOrder(
                title=title,
                type=type,
                priority=priority,
                status='pending',
                asset_id=asset_id,
                asset_name=asset_name,
                creator_id=current_user.id,
                description=description,
                sla_deadline=sla_deadline
            )
            
            session.add(new_order)
            session.commit()
            
            # 记录操作日志
            log = WorkOrderLog(
                order_id=new_order.id,
                action='创建工单',
                operator_id=current_user.id,
                content=f'创建工单：{title}'
            )
            session.add(log)
            session.commit()
            
            flash('工单创建成功')
            return redirect(url_for('workorder.list_workorders'))
        
        # GET请求，获取所有资产
        assets = session.query(Asset).all()
        
        return render_template('workorder/create.html', 
                               workorder_types=workorder_types,
                               workorder_priorities=workorder_priorities,
                               assets=assets)
    finally:
        session.close()


@bp.route('/workorder/detail/<int:order_id>')
@login_required
def workorder_detail(order_id):
    session = Session()
    try:
        # 获取工单
        order = session.query(WorkOrder).get(order_id)
        if not order:
            flash('工单不存在')
            return redirect(url_for('workorder.list_workorders'))
        
        # 获取操作日志
        logs = session.query(WorkOrderLog).filter_by(order_id=order_id).order_by(WorkOrderLog.created_at.desc()).all()
        
        # 获取处理人信息
        assignee = None
        if order.assignee_id:
            assignee = session.query(User).get(order.assignee_id)
        
        # 获取创建人信息
        creator = session.query(User).get(order.creator_id)
        
        return render_template('workorder/detail.html', 
                               order=order,
                               logs=logs,
                               assignee=assignee,
                               creator=creator)
    finally:
        session.close()


@bp.route('/workorder/accept/<int:order_id>')
@login_required
def accept_workorder(order_id):
    session = Session()
    try:
        # 获取工单
        order = session.query(WorkOrder).get(order_id)
        if not order:
            flash('工单不存在')
            return redirect(url_for('workorder.list_workorders'))
        
        # 更新状态和处理人
        order.status = 'processing'
        order.assignee_id = current_user.id
        session.commit()
        
        # 记录操作日志
        log = WorkOrderLog(
            order_id=order_id,
            action='接单',
            operator_id=current_user.id,
            content=f'接单处理工单：{order.title}'
        )
        session.add(log)
        session.commit()
        
        flash('接单成功')
        return redirect(url_for('workorder.workorder_detail', order_id=order_id))
    finally:
        session.close()


@bp.route('/workorder/complete/<int:order_id>', methods=['POST'])
@login_required
def complete_workorder(order_id):
    session = Session()
    try:
        # 获取工单
        order = session.query(WorkOrder).get(order_id)
        if not order:
            flash('工单不存在')
            return redirect(url_for('workorder.list_workorders'))
        
        # 获取处理方案
        resolution = request.form['resolution']
        
        # 更新状态和处理方案
        order.status = 'accepted'
        order.resolution = resolution
        session.commit()
        
        # 记录操作日志
        log = WorkOrderLog(
            order_id=order_id,
            action='处理完成',
            operator_id=current_user.id,
            content=f'处理完成工单：{order.title}'
        )
        session.add(log)
        session.commit()
        
        flash('处理完成')
        return redirect(url_for('workorder.workorder_detail', order_id=order_id))
    finally:
        session.close()


@bp.route('/workorder/close/<int:order_id>')
@login_required
def close_workorder(order_id):
    session = Session()
    try:
        # 获取工单
        order = session.query(WorkOrder).get(order_id)
        if not order:
            flash('工单不存在')
            return redirect(url_for('workorder.list_workorders'))
        
        # 更新状态
        order.status = 'closed'
        session.commit()
        
        # 记录操作日志
        log = WorkOrderLog(
            order_id=order_id,
            action='关闭工单',
            operator_id=current_user.id,
            content=f'关闭工单：{order.title}'
        )
        session.add(log)
        session.commit()
        
        flash('工单已关闭')
        return redirect(url_for('workorder.workorder_detail', order_id=order_id))
    finally:
        session.close()


@bp.route('/workorder/stats')
@login_required
def workorder_stats():
    session = Session()
    try:
        from datetime import datetime, timedelta
        
        # 获取今日新增工单数量
        today = datetime.utcnow().date()
        today_orders = session.query(WorkOrder).filter(
            WorkOrder.created_at >= datetime.combine(today, datetime.min.time())
        ).count()
        
        # 获取待处理工单数量
        pending_orders = session.query(WorkOrder).filter_by(status='pending').count()
        
        # 获取处理中工单数量
        processing_orders = session.query(WorkOrder).filter_by(status='processing').count()
        
        # 计算平均处理时长（小时）
        completed_orders = session.query(WorkOrder).filter(
            WorkOrder.status.in_(['accepted', 'closed']),
            WorkOrder.updated_at.isnot(None)
        ).all()
        
        total_duration = 0
        for order in completed_orders:
            if order.updated_at and order.created_at:
                duration = (order.updated_at - order.created_at).total_seconds() / 3600
                total_duration += duration
        
        avg_duration = total_duration / len(completed_orders) if completed_orders else 0
        
        # 获取最近7天的工单数量趋势
        trend_data = []
        for i in range(6, -1, -1):
            date = today - timedelta(days=i)
            count = session.query(WorkOrder).filter(
                WorkOrder.created_at >= datetime.combine(date, datetime.min.time()),
                WorkOrder.created_at < datetime.combine(date + timedelta(days=1), datetime.min.time())
            ).count()
            trend_data.append({'date': date.strftime('%m-%d'), 'count': count})
        
        # 获取工单类型分布
        type_distribution = []
        types = session.query(WorkOrder.type, func.count(WorkOrder.id)).group_by(WorkOrder.type).all()
        for type_name, count in types:
            type_distribution.append({'type': type_name, 'count': count})
        
        # 获取工单优先级分布
        priority_distribution = []
        priorities = session.query(WorkOrder.priority, func.count(WorkOrder.id)).group_by(WorkOrder.priority).all()
        for priority, count in priorities:
            priority_distribution.append({'priority': priority, 'count': count})
        
        # 获取各处理人工作量
        assignee_workload = []
        assignees = session.query(WorkOrder.assignee_id, func.count(WorkOrder.id)).group_by(WorkOrder.assignee_id).all()
        for assignee_id, count in assignees:
            if assignee_id:
                user = session.query(User).get(assignee_id)
                if user:
                    assignee_workload.append({'name': user.username, 'count': count})
        
        return render_template('workorder/stats.html',
                               today_orders=today_orders,
                               pending_orders=pending_orders,
                               processing_orders=processing_orders,
                               avg_duration=avg_duration,
                               trend_data=trend_data,
                               type_distribution=type_distribution,
                               priority_distribution=priority_distribution,
                               assignee_workload=assignee_workload)
    finally:
        session.close()
