from flask import Blueprint, render_template, jsonify, request, redirect, url_for, flash
from flask_login import login_required
from models.models import Subnet, IPAddress, Asset
from datetime import datetime
import ipaddress
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# 创建数据库连接
engine = create_engine('mysql+pymysql://root:root@localhost:3306/idc_oms?charset=utf8')
Session = sessionmaker(bind=engine)

bp = Blueprint('ip', __name__)


@bp.route('/ip/planner')
@login_required
def ip_planner():
    session = Session()
    try:
        # 获取所有子网
        subnets = session.query(Subnet).all()
        
        # 获取所有设备
        assets = session.query(Asset).all()
        
        return render_template('ip/planner.html', subnets=subnets, assets=assets)
    finally:
        session.close()


@bp.route('/ip/subnet/add', methods=['GET', 'POST'])
@login_required
def add_subnet():
    session = Session()
    try:
        if request.method == 'POST':
            # 获取表单数据
            network = request.form['network']
            prefix_len = int(request.form['prefix_len'])
            gateway = request.form['gateway']
            vlan_id = request.form.get('vlan_id', '')
            purpose = request.form.get('purpose', '')
            room = request.form.get('room', '')
            
            # 验证IP地址和前缀长度
            try:
                subnet = ipaddress.IPv4Network(f'{network}/{prefix_len}')
            except ValueError:
                flash('无效的网络地址或前缀长度')
                return redirect(url_for('ip.ip_planner'))
            
            # 计算可用主机数
            total_count = subnet.num_addresses - 2  # 减去网络地址和广播地址
            
            # 创建子网
            new_subnet = Subnet(
                network=network,
                prefix_len=prefix_len,
                gateway=gateway,
                vlan_id=vlan_id if vlan_id else None,
                purpose=purpose,
                room=room,
                total_count=total_count
            )
            
            session.add(new_subnet)
            session.commit()
            
            # 生成IP地址池
            generate_ip_addresses(new_subnet.id, str(subnet))
            
            flash('子网添加成功')
            return redirect(url_for('ip.ip_planner'))
        
        return render_template('ip/add_subnet.html')
    finally:
        session.close()


@bp.route('/ip/subnet/edit/<int:subnet_id>', methods=['GET', 'POST'])
@login_required
def edit_subnet(subnet_id):
    session = Session()
    try:
        subnet = session.query(Subnet).get(subnet_id)
        if not subnet:
            flash('子网不存在')
            return redirect(url_for('ip.ip_planner'))
        
        if request.method == 'POST':
            # 更新子网信息
            subnet.gateway = request.form['gateway']
            subnet.vlan_id = request.form.get('vlan_id', '') if request.form.get('vlan_id', '') else None
            subnet.purpose = request.form.get('purpose', '')
            subnet.room = request.form.get('room', '')
            
            session.commit()
            
            flash('子网更新成功')
            return redirect(url_for('ip.ip_planner'))
        
        return render_template('ip/edit_subnet.html', subnet=subnet)
    finally:
        session.close()


@bp.route('/ip/subnet/delete/<int:subnet_id>')
@login_required
def delete_subnet(subnet_id):
    session = Session()
    try:
        subnet = session.query(Subnet).get(subnet_id)
        if not subnet:
            flash('子网不存在')
            return redirect(url_for('ip.ip_planner'))
        
        # 删除相关的IP地址
        session.query(IPAddress).filter_by(subnet_id=subnet_id).delete()
        
        # 删除子网
        session.delete(subnet)
        session.commit()
        
        flash('子网删除成功')
        return redirect(url_for('ip.ip_planner'))
    finally:
        session.close()


@bp.route('/ip/subnet/addresses/<int:subnet_id>')
def get_subnet_addresses(subnet_id):
    session = Session()
    try:
        # 获取子网的所有IP地址
        addresses = session.query(IPAddress).filter_by(subnet_id=subnet_id).all()
        
        # 格式化数据
        address_list = []
        for addr in addresses:
            address_list.append({
                'id': addr.id,
                'address': addr.address,
                'status': addr.status,
                'asset_id': addr.asset_id
            })
        
        return jsonify(address_list)
    finally:
        session.close()


@bp.route('/ip/assign', methods=['POST'])
def assign_ip():
    session = Session()
    try:
        # 获取请求数据
        subnet_id = int(request.form['subnet_id'])
        asset_id = int(request.form['asset_id'])
        
        # 获取设备信息
        asset = session.query(Asset).get(asset_id)
        if not asset:
            return jsonify({'success': False, 'message': '设备不存在'})
        
        # 查找空闲IP
        free_ip = session.query(IPAddress).filter_by(subnet_id=subnet_id, status='free').first()
        if not free_ip:
            return jsonify({'success': False, 'message': '该子网没有空闲IP'})
        
        # 检查IP冲突
        existing_ip = session.query(IPAddress).filter_by(asset_id=asset_id).first()
        if existing_ip:
            # 释放旧IP
            existing_ip.status = 'free'
            existing_ip.asset_id = None
            existing_ip.updated_at = datetime.utcnow()
        
        # 分配新IP
        free_ip.status = 'used'
        free_ip.asset_id = asset_id
        free_ip.updated_at = datetime.utcnow()
        
        # 更新子网的使用计数
        subnet = session.query(Subnet).get(subnet_id)
        subnet.used_count = session.query(IPAddress).filter_by(subnet_id=subnet_id, status='used').count()
        
        session.commit()
        
        return jsonify({
            'success': True,
            'message': f'IP {free_ip.address} 已分配给设备 {asset.name}',
            'ip_address': free_ip.address
        })
    finally:
        session.close()


@bp.route('/ip/calculator', methods=['GET', 'POST'])
@login_required
def ip_calculator():
    if request.method == 'POST':
        # 获取表单数据
        network = request.form['network']
        prefix_len = int(request.form['prefix_len'])
        subnet_count = int(request.form['subnet_count'])
        
        try:
            # 计算子网划分
            subnets = calculate_subnets(network, prefix_len, subnet_count)
            
            return render_template('ip/calculator.html', subnets=subnets, network=network, prefix_len=prefix_len, subnet_count=subnet_count)
        except ValueError as e:
            flash(str(e))
            return redirect(url_for('ip.ip_calculator'))
    
    return render_template('ip/calculator.html')


def generate_ip_addresses(subnet_id, subnet_cidr):
    session = Session()
    try:
        # 生成子网的IP地址池
        try:
            subnet = ipaddress.IPv4Network(subnet_cidr)
            
            for addr in subnet.hosts():
                ip_address = IPAddress(
                    address=str(addr),
                    subnet_id=subnet_id
                )
                session.add(ip_address)
            
            session.commit()
        except ValueError:
            pass
    finally:
        session.close()


def calculate_subnets(network, prefix_len, subnet_count):
    # 计算等长子网划分
    try:
        base_network = ipaddress.IPv4Network(f'{network}/{prefix_len}')
        
        # 计算需要的额外前缀位数
        import math
        extra_bits = math.ceil(math.log2(subnet_count))
        new_prefix = prefix_len + extra_bits
        
        if new_prefix > 32:
            raise ValueError('需要的子网数量过多，无法进行划分')
        
        # 生成子网
        subnets = list(base_network.subnets(new_prefix=new_prefix))[:subnet_count]
        
        # 格式化结果
        result = []
        for i, subnet in enumerate(subnets):
            result.append({
                'index': i + 1,
                'network': str(subnet.network_address),
                'prefix': subnet.prefixlen,
                'netmask': str(subnet.netmask),
                'broadcast': str(subnet.broadcast_address),
                'hosts': subnet.num_addresses - 2
            })
        
        return result
    except ValueError as e:
        raise e
