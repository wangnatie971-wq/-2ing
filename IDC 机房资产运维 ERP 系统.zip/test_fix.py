# 简单的测试脚本，验证循环导入问题是否已修复

print("开始测试循环导入修复...")

# 测试导入各个模块
try:
    from routes.dashboard import bp as dashboard_bp
    print("✓ 成功导入 dashboard 模块")
except Exception as e:
    print(f"✗ 导入 dashboard 模块失败: {e}")

try:
    from routes.asset import bp as asset_bp
    print("✓ 成功导入 asset 模块")
except Exception as e:
    print(f"✗ 导入 asset 模块失败: {e}")

try:
    from routes.system import bp as system_bp
    print("✓ 成功导入 system 模块")
except Exception as e:
    print(f"✗ 导入 system 模块失败: {e}")

try:
    from routes.workorder import bp as workorder_bp
    print("✓ 成功导入 workorder 模块")
except Exception as e:
    print(f"✗ 导入 workorder 模块失败: {e}")

try:
    from routes.monitor import bp as monitor_bp
    print("✓ 成功导入 monitor 模块")
except Exception as e:
    print(f"✗ 导入 monitor 模块失败: {e}")

try:
    from routes.ip import bp as ip_bp
    print("✓ 成功导入 ip 模块")
except Exception as e:
    print(f"✗ 导入 ip 模块失败: {e}")

try:
    from routes.report import bp as report_bp
    print("✓ 成功导入 report 模块")
except Exception as e:
    print(f"✗ 导入 report 模块失败: {e}")

print("测试完成！")
