import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import matplotlib.font_manager as fm
from matplotlib.gridspec import GridSpec

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
cache_data = pd.read_pickle('data_cache.pkl')
df_traffic = cache_data['df_traffic']
df_funnel = cache_data['df_funnel']
df_promo = cache_data['df_promo']
df_user = cache_data['df_user']
df_seckill = cache_data['df_seckill']

# 处理日期字段
df_traffic['日期'] = pd.to_datetime(df_traffic['日期'])
df_funnel['日期'] = pd.to_datetime(df_funnel['日期'])
df_promo['日期'] = pd.to_datetime(df_promo['日期'])
df_user['日期'] = pd.to_datetime(df_user['日期'])
df_seckill['日期'] = pd.to_datetime(df_seckill['日期'])

# 图5：05_新老客分层分析.png
print("正在生成图5：05_新老客分层分析.png")
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 筛选大促期数据
promotion_user = df_user[df_user['是否大促'] == 1]
daily_user = df_user[df_user['是否大促'] == 0]

# 子图1：新客大促每日GMV折线（左上）
new_customer_promotion = promotion_user[promotion_user['用户类型'] == '新客'].copy()
new_customer_promotion['日期'] = pd.to_datetime(new_customer_promotion['日期'])
new_customer_daily_gmv = new_customer_promotion.groupby('日期')['GMV'].sum()

x1 = range(len(new_customer_daily_gmv))
axes[0, 0].plot(x1, new_customer_daily_gmv.values, color='#e74c3c', linewidth=2, marker='o', label='GMV')
axes[0, 0].fill_between(x1, new_customer_daily_gmv.values, color='#e74c3c', alpha=0.3)
axes[0, 0].set_xlabel('大促天数', fontsize=12)
axes[0, 0].set_ylabel('GMV (元)', fontsize=12)
axes[0, 0].set_xticks(x1)
axes[0, 0].set_xticklabels([f"第{i+1}天" for i in x1], rotation=45)
axes[0, 0].set_title('新客大促每日GMV趋势', fontsize=13, fontweight='bold')
axes[0, 0].legend()
axes[0, 0].grid(True, alpha=0.3)

# 子图2：老客大促每日GMV折线（右上）
old_customer_promotion = promotion_user[promotion_user['用户类型'] == '老客'].copy()
old_customer_promotion['日期'] = pd.to_datetime(old_customer_promotion['日期'])
old_customer_daily_gmv = old_customer_promotion.groupby('日期')['GMV'].sum()

x2 = range(len(old_customer_daily_gmv))
axes[0, 1].plot(x2, old_customer_daily_gmv.values, color='#3498db', linewidth=2, marker='o', label='GMV')
axes[0, 1].fill_between(x2, old_customer_daily_gmv.values, color='#3498db', alpha=0.3)
axes[0, 1].set_xlabel('大促天数', fontsize=12)
axes[0, 1].set_ylabel('GMV (元)', fontsize=12)
axes[0, 1].set_xticks(x2)
axes[0, 1].set_xticklabels([f"第{i+1}天" for i in x2], rotation=45)
axes[0, 1].set_title('老客大促每日GMV趋势', fontsize=13, fontweight='bold')
axes[0, 1].legend()
axes[0, 1].grid(True, alpha=0.3)

# 子图3：新老客日均GMV对比柱状图（左下）
new_promotion_avg = new_customer_promotion.groupby('日期')['GMV'].sum().mean()
new_daily_avg = daily_user[daily_user['用户类型'] == '新客'].groupby('日期')['GMV'].sum().mean()
old_promotion_avg = old_customer_promotion.groupby('日期')['GMV'].sum().mean()
old_daily_avg = daily_user[daily_user['用户类型'] == '老客'].groupby('日期')['GMV'].sum().mean()

x3 = np.arange(4)
width = 0.35
bars3 = axes[1, 0].bar(x3, [new_daily_avg, new_promotion_avg, old_daily_avg, old_promotion_avg], 
                        color=['#95a5a6', '#e74c3c', '#95a5a6', '#3498db'], alpha=0.8, width=width)
axes[1, 0].set_ylabel('日均GMV (元)', fontsize=12)
axes[1, 0].set_xticks(x3)
axes[1, 0].set_xticklabels(['新客日常', '新客大促', '老客日常', '老客大促'], fontsize=10)
axes[1, 0].set_title('新老客日均GMV对比', fontsize=13, fontweight='bold')
for bar, value in zip(bars3, [new_daily_avg, new_promotion_avg, old_daily_avg, old_promotion_avg]):
    axes[1, 0].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                    f'{value:,.0f}', ha='center', va='bottom', fontsize=9)

# 子图4：新老客ROI对比柱状图（右下）
new_promotion_roi = new_customer_promotion['ROI'].mean()
new_daily_roi = daily_user[daily_user['用户类型'] == '新客']['ROI'].mean()
old_promotion_roi = old_customer_promotion['ROI'].mean()
old_daily_roi = daily_user[daily_user['用户类型'] == '老客']['ROI'].mean()

bars4 = axes[1, 1].bar(x3, [new_daily_roi, new_promotion_roi, old_daily_roi, old_promotion_roi], 
                        color=['#95a5a6', '#e74c3c', '#95a5a6', '#3498db'], alpha=0.8, width=width)
axes[1, 1].set_ylabel('ROI', fontsize=12)
axes[1, 1].set_xticks(x3)
axes[1, 1].set_xticklabels(['新客日常', '新客大促', '老客日常', '老客大促'], fontsize=10)
axes[1, 1].set_title('新老客ROI对比', fontsize=13, fontweight='bold')
for bar, value in zip(bars4, [new_daily_roi, new_promotion_roi, old_daily_roi, old_promotion_roi]):
    axes[1, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                    f'{value:.2f}', ha='center', va='bottom', fontsize=9)

plt.suptitle('新老客分层分析', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('05_新老客分层分析.png', dpi=150, bbox_inches='tight')
plt.close()

print("图5生成完成！")

# 图6：06_秒杀峰值分析.png
print("正在生成图6：06_秒杀峰值分析.png")
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 阶段颜色映射
stage_colors = {
    '预热期': '#f39c12',
    '爆发期': '#e74c3c', 
    '高潮期': '#9b59b6',
    '尾声期': '#3498db'
}

# 子图1：各阶段分时段平均订单量折线（左上）
time_slots = ['10:00', '12:00', '15:00', '20:00', '22:00']
stages = ['预热期', '爆发期', '高潮期', '尾声期']

for stage in stages:
    stage_data = df_seckill[df_seckill['大促天数'] <= 10].copy()
    if stage == '预热期':
        stage_data = stage_data[stage_data['大促天数'] <= 2]
    elif stage == '爆发期':
        stage_data = stage_data[(stage_data['大促天数'] > 2) & (stage_data['大促天数'] <= 5)]
    elif stage == '高潮期':
        stage_data = stage_data[(stage_data['大促天数'] > 5) & (stage_data['大促天数'] <= 7)]
    else:  # 尾声期
        stage_data = stage_data[stage_data['大促天数'] > 7]
    
    avg_orders_by_time = stage_data.groupby('时段')['订单量'].mean()
    axes[0, 0].plot(time_slots, avg_orders_by_time.values, color=stage_colors[stage], 
                    linewidth=2, marker='o', label=stage)

axes[0, 0].set_xlabel('时段', fontsize=12)
axes[0, 0].set_ylabel('平均订单量', fontsize=12)
axes[0, 0].set_title('各阶段分时段平均订单量', fontsize=13, fontweight='bold')
axes[0, 0].legend()
axes[0, 0].grid(True, alpha=0.3)

# 子图2：各时段平均退款率柱状图（右上）
avg_refund_by_time = df_seckill.groupby('时段')['退款率'].mean() * 100
x2 = range(len(time_slots))
bars2 = axes[0, 1].bar(x2, avg_refund_by_time.values, color='#e74c3c', alpha=0.8, width=0.6)
axes[0, 1].set_xticks(x2)
axes[0, 1].set_xticklabels(time_slots, fontsize=11)
axes[0, 1].set_ylabel('平均退款率 (%)', fontsize=12)
axes[0, 1].set_title('各时段平均退款率', fontsize=13, fontweight='bold')
for bar, rate in zip(bars2, avg_refund_by_time.values):
    axes[0, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                    f'{rate:.1f}%', ha='center', va='bottom', fontsize=10)

# 子图3：订单量柱状图+系统负载折线双Y轴（左下）
avg_orders_by_time = df_seckill.groupby('时段')['订单量'].mean()
avg_load_by_time = df_seckill.groupby('时段')['系统负载(%)'].mean()

x3 = range(len(time_slots))
bars3 = axes[1, 0].bar(x3, avg_orders_by_time.values, color='#3498db', alpha=0.6, width=0.6, label='订单量')
axes[1, 0].set_xticks(x3)
axes[1, 0].set_xticklabels(time_slots, fontsize=11)
axes[1, 0].set_ylabel('订单量', fontsize=12, color='#3498db')
axes[1, 0].tick_params(axis='y', labelcolor='#3498db')

# 添加80%警戒虚线
axes[1, 0].axhline(y=80, color='red', linestyle='--', linewidth=1.5, alpha=0.7, label='80%警戒线')

# 创建右Y轴
ax3_right = axes[1, 0].twinx()
line3 = ax3_right.plot(x3, avg_load_by_time.values, color='#e74c3c', linewidth=2, marker='s', label='系统负载')
ax3_right.set_ylabel('系统负载 (%)', fontsize=12, color='#e74c3c')
ax3_right.tick_params(axis='y', labelcolor='#e74c3c')
ax3_right.set_ylim(0, 100)

axes[1, 0].set_title('订单量与系统负载', fontsize=13, fontweight='bold')

# 合并图例
lines1, labels1 = axes[1, 0].get_legend_handles_labels()
lines2, labels2 = ax3_right.get_legend_handles_labels()
axes[1, 0].legend(lines1 + lines2, labels1 + labels2, loc='upper left')

# 子图4：各时段平均响应时间柱状图（右下）
avg_response_by_time = df_seckill.groupby('时段')['平均响应时间(ms)'].mean()

# 按响应时间设置颜色
response_colors = []
for response in avg_response_by_time.values:
    if response < 200:
        response_colors.append('#2ecc71')  # 绿色
    elif response < 300:
        response_colors.append('#f39c12')  # 橙色
    else:
        response_colors.append('#e74c3c')  # 红色

x4 = range(len(time_slots))
bars4 = axes[1, 1].bar(x4, avg_response_by_time.values, color=response_colors, alpha=0.8, width=0.6)
axes[1, 1].set_xticks(x4)
axes[1, 1].set_xticklabels(time_slots, fontsize=11)
axes[1, 1].set_ylabel('平均响应时间 (ms)', fontsize=12)
axes[1, 1].set_title('各时段平均响应时间', fontsize=13, fontweight='bold')

# 添加200ms和300ms警戒虚线
axes[1, 1].axhline(y=200, color='orange', linestyle='--', linewidth=1.5, alpha=0.7, label='200ms警戒线')
axes[1, 1].axhline(y=300, color='red', linestyle='--', linewidth=1.5, alpha=0.7, label='300ms警戒线')
axes[1, 1].legend(loc='upper right', fontsize=9)

for bar, response in zip(bars4, avg_response_by_time.values):
    axes[1, 1].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                    f'{response:.0f}', ha='center', va='bottom', fontsize=10)

plt.suptitle('秒杀峰值分析', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('06_秒杀峰值分析.png', dpi=150, bbox_inches='tight')
plt.close()

print("图6生成完成！")

# 图7：07_活动后回落分析.png
print("正在生成图7：07_活动后回落分析.png")
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

# 定义时间段
pre_promotion = pd.date_range('2026-02-22', '2026-02-28')  # 大促前7天
promotion = pd.date_range('2026-03-01', '2026-03-10')  # 大促10天
post_promotion = pd.date_range('2026-03-11', '2026-03-15')  # 大促后5天

# 筛选各阶段数据
pre_traffic = df_traffic[df_traffic['日期'].isin(pre_promotion)]
promo_traffic = df_traffic[df_traffic['日期'].isin(promotion)]
post_traffic = df_traffic[df_traffic['日期'].isin(post_promotion)]

# 计算各阶段日均指标
pre_avg_uv = pre_traffic['UV'].mean()
promo_avg_uv = promo_traffic['UV'].mean()
post_avg_uv = post_traffic['UV'].mean()

pre_funnel = df_funnel[df_funnel['日期'].isin(pre_promotion)]
promo_funnel = df_funnel[df_funnel['日期'].isin(promotion)]
post_funnel = df_funnel[df_funnel['日期'].isin(post_promotion)]

pre_user = df_user[df_user['日期'].isin(pre_promotion)]
promo_user = df_user[df_user['日期'].isin(promotion)]
post_user = df_user[df_user['日期'].isin(post_promotion)]

# 计算日均GMV
pre_avg_gmv = pre_user.groupby('日期')['GMV'].sum().mean() / 10000  # 转换为万元
promo_avg_gmv = promo_user.groupby('日期')['GMV'].sum().mean() / 10000
post_avg_gmv = post_user.groupby('日期')['GMV'].sum().mean() / 10000

# 计算转化率
pre_conversion = (pre_funnel['完成支付'].sum() / pre_funnel['UV'].sum()) * 100
promo_conversion = (promo_funnel['完成支付'].sum() / promo_funnel['UV'].sum()) * 100
post_conversion = (post_funnel['完成支付'].sum() / post_funnel['UV'].sum()) * 100

# 计算下降百分比
uv_decline = ((post_avg_uv - promo_avg_uv) / promo_avg_uv) * 100
gmv_decline = ((post_avg_gmv - promo_avg_gmv) / promo_avg_gmv) * 100
conversion_decline = ((post_conversion - promo_conversion) / promo_conversion) * 100

# 子图1：日均UV
x1 = np.arange(3)
bars1 = axes[0].bar(x1, [pre_avg_uv, promo_avg_uv, post_avg_uv], 
                     color=['#95a5a6', '#e74c3c', '#3498db'], alpha=0.8, width=0.6)
axes[0].set_ylabel('日均UV', fontsize=12)
axes[0].set_xticks(x1)
axes[0].set_xticklabels(['大促前7天', '大促10天', '大促后5天'], fontsize=11)
axes[0].set_title('日均UV对比', fontsize=13, fontweight='bold')
axes[0].text(2, post_avg_uv * 1.05, f'↓{abs(uv_decline):.1f}%', 
             ha='center', fontsize=12, color='#e74c3c', fontweight='bold')
for bar, value in zip(bars1, [pre_avg_uv, promo_avg_uv, post_avg_uv]):
    axes[0].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                f'{value:,.0f}', ha='center', va='bottom', fontsize=10)

# 子图2：日均GMV
bars2 = axes[1].bar(x1, [pre_avg_gmv, promo_avg_gmv, post_avg_gmv], 
                     color=['#95a5a6', '#e74c3c', '#3498db'], alpha=0.8, width=0.6)
axes[1].set_ylabel('日均GMV (万元)', fontsize=12)
axes[1].set_xticks(x1)
axes[1].set_xticklabels(['大促前7天', '大促10天', '大促后5天'], fontsize=11)
axes[1].set_title('日均GMV对比', fontsize=13, fontweight='bold')
axes[1].text(2, post_avg_gmv * 1.05, f'↓{abs(gmv_decline):.1f}%', 
             ha='center', fontsize=12, color='#e74c3c', fontweight='bold')
for bar, value in zip(bars2, [pre_avg_gmv, promo_avg_gmv, post_avg_gmv]):
    axes[1].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                f'{value:.1f}', ha='center', va='bottom', fontsize=10)

# 子图3：转化率
bars3 = axes[2].bar(x1, [pre_conversion, promo_conversion, post_conversion], 
                     color=['#95a5a6', '#e74c3c', '#3498db'], alpha=0.8, width=0.6)
axes[2].set_ylabel('转化率 (%)', fontsize=12)
axes[2].set_xticks(x1)
axes[2].set_xticklabels(['大促前7天', '大促10天', '大促后5天'], fontsize=11)
axes[2].set_title('转化率对比', fontsize=13, fontweight='bold')
axes[2].text(2, post_conversion * 1.05, f'↓{abs(conversion_decline):.1f}%', 
             ha='center', fontsize=12, color='#e74c3c', fontweight='bold')
for bar, value in zip(bars3, [pre_conversion, promo_conversion, post_conversion]):
    axes[2].text(bar.get_x() + bar.get_width()/2, bar.get_height(), 
                f'{value:.2f}%', ha='center', va='bottom', fontsize=10)

plt.suptitle('活动后回落分析', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('07_活动后回落分析.png', dpi=150, bbox_inches='tight')
plt.close()

print("图7生成完成！")

# 图8：08_综合数据看板.png
print("正在生成图8：08_综合数据看板.png")
fig = plt.figure(figsize=(20, 14))
gs = GridSpec(2, 3, figure=fig, hspace=0.3, wspace=0.3)

# [0,0] 核心KPI卡片
ax_kpi = fig.add_subplot(gs[0, 0])
ax_kpi.axis('off')

# 计算核心KPI
total_gmv = df_user['GMV'].sum() / 10000  # 转换为万元
total_uv = df_traffic['UV'].sum()
total_orders = df_funnel['完成支付'].sum()
overall_conversion = (total_orders / total_uv) * 100

kpi_data = [
    {'label': '总GMV', 'value': f'{total_gmv:.1f}万', 'color': '#e74c3c'},
    {'label': '总UV', 'value': f'{total_uv:,.0f}', 'color': '#3498db'},
    {'label': '总订单', 'value': f'{total_orders:,.0f}', 'color': '#2ecc71'},
    {'label': '整体转化率', 'value': f'{overall_conversion:.2f}%', 'color': '#f39c12'}
]

for i, kpi in enumerate(kpi_data):
    y_pos = 0.8 - i * 0.2
    ax_kpi.text(0.1, y_pos, kpi['label'], fontsize=12, color='#7f8c8d', fontweight='bold')
    ax_kpi.text(0.1, y_pos - 0.08, kpi['value'], fontsize=18, color=kpi['color'], fontweight='bold')

ax_kpi.set_title('核心KPI', fontsize=14, fontweight='bold', pad=20)

# [0,1:] 跨2列每日GMV趋势
ax_trend = fig.add_subplot(gs[0, 1:])
daily_gmv = df_user.groupby('日期')['GMV'].sum() / 10000  # 转换为万元
x_trend = range(len(daily_gmv))

# 绘制GMV趋势
ax_trend.plot(x_trend, daily_gmv.values, color='#2c3e50', linewidth=2, marker='o', markersize=4)

# 高亮大促期背景
promotion_start = len([d for d in df_traffic['日期'] if d < pd.Timestamp('2026-03-01')])
promotion_end = promotion_start + 10
ax_trend.axvspan(promotion_start - 0.5, promotion_end - 0.5, color='#e74c3c', alpha=0.1, label='大促期')

ax_trend.set_xlabel('日期', fontsize=12)
ax_trend.set_ylabel('GMV (万元)', fontsize=12)
ax_trend.set_title('每日GMV趋势', fontsize=14, fontweight='bold')
ax_trend.legend(loc='upper left')
ax_trend.grid(True, alpha=0.3)

# [1,0] 步骤转化率对比柱状图
ax_steps = fig.add_subplot(gs[1, 0])

funnel_steps = ['UV到详情', '详情到加购', '加购到下单', '下单到支付']
step_labels = ['UV→详情', '详情→加购', '加购→下单', '下单→支付']

# 计算大促期和日常期转化率
promotion_funnel = df_funnel[df_funnel['是否大促'] == 1]
daily_funnel = df_funnel[df_funnel['是否大促'] == 0]

promotion_rates = []
daily_rates = []

# UV到详情
promotion_rates.append((promotion_funnel['浏览商品详情'].sum() / promotion_funnel['UV'].sum()) * 100)
daily_rates.append((daily_funnel['浏览商品详情'].sum() / daily_funnel['UV'].sum()) * 100)

# 详情到加购
promotion_rates.append((promotion_funnel['加入购物车'].sum() / promotion_funnel['浏览商品详情'].sum()) * 100)
daily_rates.append((daily_funnel['加入购物车'].sum() / daily_funnel['浏览商品详情'].sum()) * 100)

# 加购到下单
promotion_rates.append((promotion_funnel['提交订单'].sum() / promotion_funnel['加入购物车'].sum()) * 100)
daily_rates.append((daily_funnel['提交订单'].sum() / daily_funnel['加入购物车'].sum()) * 100)

# 下单到支付
promotion_rates.append((promotion_funnel['完成支付'].sum() / promotion_funnel['提交订单'].sum()) * 100)
daily_rates.append((daily_funnel['完成支付'].sum() / daily_funnel['提交订单'].sum()) * 100)

x_steps = np.arange(len(step_labels))
width = 0.35

bars_steps1 = ax_steps.bar(x_steps - width/2, daily_rates, width, label='日常期', color='#95a5a6', alpha=0.8)
bars_steps2 = ax_steps.bar(x_steps + width/2, promotion_rates, width, label='大促期', color='#e74c3c', alpha=0.8)

ax_steps.set_ylabel('转化率 (%)', fontsize=12)
ax_steps.set_xticks(x_steps)
ax_steps.set_xticklabels(step_labels, fontsize=10)
ax_steps.set_title('步骤转化率对比', fontsize=14, fontweight='bold')
ax_steps.legend()
ax_steps.grid(True, alpha=0.3, axis='y')

# [1,1] 新老客GMV占比环形饼图
ax_pie = fig.add_subplot(gs[1, 1])

# 计算新老客GMV占比
new_customer_gmv = df_user[df_user['用户类型'] == '新客']['GMV'].sum()
old_customer_gmv = df_user[df_user['用户类型'] == '老客']['GMV'].sum()

pie_data = [new_customer_gmv, old_customer_gmv]
pie_labels = ['新客', '老客']
pie_colors = ['#e74c3c', '#3498db']

wedges, texts, autotexts = ax_pie.pie(pie_data, labels=pie_labels, colors=pie_colors, 
                                     autopct='%1.1f%%', startangle=90, 
                                     wedgeprops={'width': 0.4, 'edgecolor': 'white'})

for autotext in autotexts:
    autotext.set_color('white')
    autotext.set_fontsize(12)
    autotext.set_fontweight('bold')

ax_pie.set_title('新老客GMV占比', fontsize=14, fontweight='bold')

# [1,2] 核销率排名柱状图
ax_ranking = fig.add_subplot(gs[1, 2])

# 计算各优惠类型核销率
promo_ranking = df_promo.groupby('优惠类型').agg({
    '发放量': 'sum',
    '核销量': 'sum'
}).reset_index()

promo_ranking['核销率'] = (promo_ranking['核销量'] / promo_ranking['发放量'] * 100)
promo_ranking = promo_ranking.sort_values('核销率', ascending=True)

# 颜色映射
promo_colors_ranking = {
    '满200减30': '#e74c3c',
    '满300减50': '#e67e22',
    '满500减100': '#f39c12',
    '限时折扣': '#9b59b6',
    '无门槛券5元': '#3498db',
    '无门槛券10元': '#1abc9c'
}

x_ranking = range(len(promo_ranking))
colors_ranking = [promo_colors_ranking[promo] for promo in promo_ranking['优惠类型']]

bars_ranking = ax_ranking.barh(x_ranking, promo_ranking['核销率'], color=colors_ranking, alpha=0.8)
ax_ranking.set_yticks(x_ranking)
ax_ranking.set_yticklabels(promo_ranking['优惠类型'], fontsize=10)
ax_ranking.set_xlabel('核销率 (%)', fontsize=12)
ax_ranking.set_title('优惠类型核销率排名', fontsize=14, fontweight='bold')
ax_ranking.grid(True, alpha=0.3, axis='x')

for bar, rate in zip(bars_ranking, promo_ranking['核销率']):
    ax_ranking.text(bar.get_width(), bar.get_y() + bar.get_height()/2, 
                  f'{rate:.1f}%', va='center', ha='left', fontsize=9)

fig.suptitle('电商大促活动复盘 — 综合数据看板', fontsize=18, fontweight='bold', y=0.98)
plt.savefig('08_综合数据看板.png', dpi=150, bbox_inches='tight')
plt.close()

print("图8生成完成！")
print("\n所有图表生成完成！")
