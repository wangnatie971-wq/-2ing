import pandas as pd
import base64
import glob
from datetime import datetime

# 读取数据
cache_data = pd.read_pickle('data_cache.pkl')
df_traffic = cache_data['df_traffic']
df_funnel = cache_data['df_funnel']
df_promo = cache_data['df_promo']
df_user = cache_data['df_user']
df_seckill = cache_data['df_seckill']

# 处理日期字段
df_traffic['日期'] = pd.to_datetime(df_traffic['日期'])
df_funnel['日期'] = pd.to_datetime(df_funnel['日期'])
df_promo['日期'] = pd.to_datetime(df_promo['日期'])
df_user['日期'] = pd.to_datetime(df_user['日期'])
df_seckill['日期'] = pd.to_datetime(df_seckill['日期'])

# 计算核心KPI
total_gmv = df_user['GMV'].sum() / 10000  # 转换为万元
total_uv = df_traffic['UV'].sum()
total_orders = df_funnel['完成支付'].sum()
overall_conversion = (total_orders / total_uv) * 100
avg_order_value = df_user['客单价'].mean()
actual_gmv = df_user['实际GMV'].sum()
total_marketing_cost = df_user['营销成本'].sum()
roi = actual_gmv / total_marketing_cost

# 计算大促期和日常期对比
funnel_promotion = df_funnel[df_funnel['是否大促'] == 1]
funnel_daily = df_funnel[df_funnel['是否大促'] == 0]
user_promotion = df_user[df_user['是否大促'] == 1]
user_daily = df_user[df_user['是否大促'] == 0]

promotion_avg_uv = funnel_promotion['UV'].mean()
daily_avg_uv = funnel_daily['UV'].mean()
uv_multiplier = promotion_avg_uv / daily_avg_uv

promotion_conversion = (funnel_promotion['完成支付'].sum() / funnel_promotion['UV'].sum()) * 100
daily_conversion = (funnel_daily['完成支付'].sum() / funnel_daily['UV'].sum()) * 100
conversion_multiplier = promotion_conversion / daily_conversion

promotion_aov = user_promotion['客单价'].mean()
daily_aov = user_daily['客单价'].mean()
aov_multiplier = promotion_aov / daily_aov

promotion_avg_gmv = user_promotion.groupby('日期')['GMV'].sum().mean() / 10000
daily_avg_gmv = user_daily.groupby('日期')['GMV'].sum().mean() / 10000
gmv_multiplier = promotion_avg_gmv / daily_avg_gmv

# 优惠策略汇总
promo_summary = df_promo.groupby('优惠类型').agg({
    '发放量': 'sum',
    '核销量': 'sum',
    '客单价': 'mean',
    'GMV贡献': 'sum'
}).reset_index()
promo_summary['核销率'] = (promo_summary['核销量'] / promo_summary['发放量'] * 100)
promo_summary = promo_summary.sort_values('GMV贡献', ascending=False)

# 新老客分析
new_customer = df_user[df_user['用户类型'] == '新客']
old_customer = df_user[df_user['用户类型'] == '老客']

new_promotion_gmv = new_customer[new_customer['是否大促'] == 1]['GMV'].sum() / 10000
old_promotion_gmv = old_customer[old_customer['是否大促'] == 1]['GMV'].sum() / 10000
new_promotion_roi = new_customer[new_customer['是否大促'] == 1]['ROI'].mean()
old_promotion_roi = old_customer[old_customer['是否大促'] == 1]['ROI'].mean()

# 秒杀峰值分析
avg_orders_by_time = df_seckill.groupby('时段')['订单量'].mean()
avg_refund_by_time = df_seckill.groupby('时段')['退款率'].mean() * 100
avg_response_by_time = df_seckill.groupby('时段')['平均响应时间(ms)'].mean()
avg_load_by_time = df_seckill.groupby('时段')['系统负载(%)'].mean()

# 活动后回落分析
pre_promotion = pd.date_range('2026-02-22', '2026-02-28')
promotion = pd.date_range('2026-03-01', '2026-03-10')
post_promotion = pd.date_range('2026-03-11', '2026-03-15')

pre_traffic = df_traffic[df_traffic['日期'].isin(pre_promotion)]
promo_traffic = df_traffic[df_traffic['日期'].isin(promotion)]
post_traffic = df_traffic[df_traffic['日期'].isin(post_promotion)]

pre_avg_uv = pre_traffic['UV'].mean()
promo_avg_uv = promo_traffic['UV'].mean()
post_avg_uv = post_traffic['UV'].mean()
uv_decline = ((post_avg_uv - promo_avg_uv) / promo_avg_uv) * 100

pre_funnel = df_funnel[df_funnel['日期'].isin(pre_promotion)]
promo_funnel = df_funnel[df_funnel['日期'].isin(promotion)]
post_funnel = df_funnel[df_funnel['日期'].isin(post_promotion)]

pre_user = df_user[df_user['日期'].isin(pre_promotion)]
promo_user = df_user[df_user['日期'].isin(promotion)]
post_user = df_user[df_user['日期'].isin(post_promotion)]

pre_avg_gmv = pre_user.groupby('日期')['GMV'].sum().mean() / 10000
promo_avg_gmv = promo_user.groupby('日期')['GMV'].sum().mean() / 10000
post_avg_gmv = post_user.groupby('日期')['GMV'].sum().mean() / 10000
gmv_decline = ((post_avg_gmv - promo_avg_gmv) / promo_avg_gmv) * 100

pre_conversion = (pre_funnel['完成支付'].sum() / pre_funnel['UV'].sum()) * 100
promo_conversion = (promo_funnel['完成支付'].sum() / promo_funnel['UV'].sum()) * 100
post_conversion = (post_funnel['完成支付'].sum() / post_funnel['UV'].sum()) * 100
conversion_decline = ((post_conversion - promo_conversion) / promo_conversion) * 100

# 读取图片并转换为base64
def image_to_base64(image_path):
    try:
        with open(image_path, 'rb') as image_file:
            return base64.b64encode(image_file.read()).decode()
    except:
        return ""

images = {}
for i in range(1, 9):
    matching_files = glob.glob(f'0{i}_*.png')
    if matching_files:
        images[f'图{i}'] = image_to_base64(matching_files[0])

# 生成HTML报告
html_content = f"""
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>电商平台'321周年庆'大促复盘报告</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Microsoft YaHei', '微软雅黑', Arial, sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            color: #e2e8f0;
            line-height: 1.6;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        
        .header {{
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            border-radius: 15px;
            border: 1px solid #475569;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }}
        
        .header h1 {{
            font-size: 2.5em;
            color: #60a5fa;
            margin-bottom: 10px;
            text-shadow: 0 0 20px rgba(96, 165, 250, 0.3);
        }}
        
        .header .subtitle {{
            font-size: 1.2em;
            color: #94a3b8;
            margin-top: 10px;
        }}
        
        .kpi-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }}
        
        .kpi-card {{
            background: linear-gradient(135deg, #1e293b 0%, #334155 100%);
            border-radius: 15px;
            padding: 25px;
            border: 1px solid #475569;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}
        
        .kpi-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }}
        
        .kpi-card.gmv {{
            background: linear-gradient(135deg, #059669 0%, #10b981 100%);
        }}
        
        .kpi-card.uv {{
            background: linear-gradient(135deg, #2563eb 0%, #3b82f6 100%);
        }}
        
        .kpi-card.conversion {{
            background: linear-gradient(135deg, #7c3aed 0%, #8b5cf6 100%);
        }}
        
        .kpi-card.aov {{
            background: linear-gradient(135deg, #ea580c 0%, #f97316 100%);
        }}
        
        .kpi-card.roi {{
            background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%);
        }}
        
        .kpi-title {{
            font-size: 1em;
            color: rgba(255, 255, 255, 0.8);
            margin-bottom: 10px;
        }}
        
        .kpi-value {{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }}
        
        .section {{
            background: #1e293b;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            border: 1px solid #334155;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }}
        
        .section h2 {{
            color: #60a5fa;
            font-size: 1.8em;
            margin-bottom: 25px;
            border-bottom: 2px solid #334155;
            padding-bottom: 15px;
        }}
        
        .chart-container {{
            text-align: center;
            margin: 25px 0;
            padding: 20px;
            background: #0f172a;
            border-radius: 10px;
            border: 1px solid #334155;
        }}
        
        .chart-container img {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            border: 1px solid #475569;
        }}
        
        .insight-box {{
            background: #451a03;
            border-left: 4px solid #fbbf24;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
        }}
        
        .insight-box h3 {{
            color: #fbbf24;
            margin-bottom: 10px;
            font-size: 1.2em;
        }}
        
        .insight-box p {{
            color: #fef3c7;
            line-height: 1.8;
        }}
        
        .recommendation-box {{
            background: #14532d;
            border-left: 4px solid #22c55e;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
        }}
        
        .recommendation-box h3 {{
            color: #22c55e;
            margin-bottom: 10px;
            font-size: 1.2em;
        }}
        
        .recommendation-box p {{
            color: #dcfce7;
            line-height: 1.8;
        }}
        
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: #1e293b;
            border-radius: 10px;
            overflow: hidden;
        }}
        
        .data-table th {{
            background: #334155;
            color: #e2e8f0;
            padding: 15px;
            text-align: left;
            font-weight: bold;
            border-bottom: 2px solid #475569;
        }}
        
        .data-table td {{
            padding: 12px 15px;
            border-bottom: 1px solid #334155;
            color: #cbd5e1;
        }}
        
        .data-table tr:hover {{
            background: #334155;
        }}
        
        .data-table tr:last-child td {{
            border-bottom: none;
        }}
        
        .highlight {{
            color: #60a5fa;
            font-weight: bold;
        }}
        
        .footer {{
            text-align: center;
            padding: 30px;
            color: #64748b;
            font-size: 0.9em;
            margin-top: 40px;
            border-top: 1px solid #334155;
        }}
        
        .recommendation-list {{
            list-style: none;
            padding: 0;
        }}
        
        .recommendation-list li {{
            background: #1e293b;
            border-left: 4px solid #22c55e;
            padding: 15px 20px;
            margin: 15px 0;
            border-radius: 8px;
            transition: transform 0.3s ease;
        }}
        
        .recommendation-list li:hover {{
            transform: translateX(10px);
            background: #334155;
        }}
        
        .recommendation-list strong {{
            color: #22c55e;
            display: block;
            margin-bottom: 5px;
        }}
        
        @media (max-width: 768px) {{
            .kpi-grid {{
                grid-template-columns: 1fr;
            }}
            
            .header h1 {{
                font-size: 1.8em;
            }}
            
            .section {{
                padding: 20px;
            }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>电商平台'321周年庆'大促复盘报告</h1>
            <div class="subtitle">活动周期：2026年2月1日 - 2026年3月15日（共43天）</div>
        </div>
        
        <div class="kpi-grid">
            <div class="kpi-card gmv">
                <div class="kpi-title">总GMV</div>
                <div class="kpi-value">{total_gmv:.1f}万元</div>
            </div>
            <div class="kpi-card uv">
                <div class="kpi-title">日均UV</div>
                <div class="kpi-value">{total_uv/43:,.0f}</div>
            </div>
            <div class="kpi-card conversion">
                <div class="kpi-title">整体转化率</div>
                <div class="kpi-value">{overall_conversion:.2f}%</div>
            </div>
            <div class="kpi-card aov">
                <div class="kpi-title">客单价</div>
                <div class="kpi-value">{avg_order_value:.2f}元</div>
            </div>
            <div class="kpi-card roi">
                <div class="kpi-title">ROI</div>
                <div class="kpi-value">{roi:.2f}</div>
            </div>
        </div>
        
        <div class="section">
            <h2>1. 大促各阶段趋势</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图1', '')}" alt="大促阶段流量与GMV趋势">
            </div>
            <div class="insight-box">
                <h3>关键发现</h3>
                <p>大促期UV达到日均71,577，相比日常期提升{uv_multiplier:.2f}倍。高潮期（第6-7天）流量和GMV均达到峰值，预热期和爆发期呈现稳步增长趋势。高潮期后流量开始回落，尾声期仍保持较高水平。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>2. GMV核心拆解</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图2', '')}" alt="GMV拆解对比">
            </div>
            <div class="insight-box">
                <h3>核心结论</h3>
                <p>大促期GMV提升{gmv_multiplier:.2f}倍，主要由三个因素驱动：UV提升{uv_multiplier:.2f}倍、转化率提升{conversion_multiplier:.2f}倍、客单价提升{aov_multiplier:.2f}倍。其中转化率提升最为显著，说明大促期间用户购买意愿强烈。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>3. 用户路径漏斗</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图3', '')}" alt="用户路径漏斗对比">
            </div>
            <div class="insight-box">
                <h3>流失分析</h3>
                <p>大促期加购到下单转化率（37.68%）显著高于日常期（19.87%），提升近一倍，说明大促优惠有效刺激用户下单。但详情到加购环节仍有优化空间，可考虑增加加购引导和限时优惠提醒。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>4. 优惠策略对比</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图4', '')}" alt="优惠策略综合对比">
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>优惠类型</th>
                        <th>总发放量</th>
                        <th>总核销量</th>
                        <th>核销率</th>
                        <th>总GMV贡献</th>
                    </tr>
                </thead>
                <tbody>"""

# 添加优惠策略表格行
for _, row in promo_summary.iterrows():
    html_content += f"""
                    <tr>
                        <td class="highlight">{row['优惠类型']}</td>
                        <td>{row['发放量']:,}</td>
                        <td>{row['核销量']:,}</td>
                        <td>{row['核销率']:.2f}%</td>
                        <td>{row['GMV贡献']/10000:.1f}万元</td>
                    </tr>"""

html_content += """
                </tbody>
            </table>
            <div class="insight-box">
                <h3>策略结论</h3>
                <p>满500减100虽然核销率最低（43.68%），但客单价最高（658.49元），GMV贡献最大（6,244万元）。限时折扣核销率最高（87.61%），适合提升转化率。建议组合使用高门槛满减券和限时折扣。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>5. 新老客分层分析</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图5', '')}" alt="新老客分层分析">
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>用户类型</th>
                        <th>大促期总GMV</th>
                        <th>大促期ROI</th>
                        <th>日均GMV</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="highlight">新客</td>
                        <td>{new_promotion_gmv:.1f}万元</td>
                        <td>{new_promotion_roi:.2f}</td>
                        <td>{new_promotion_gmv/10:.1f}万元</td>
                    </tr>
                    <tr>
                        <td class="highlight">老客</td>
                        <td>{old_promotion_gmv:.1f}万元</td>
                        <td>{old_promotion_roi:.2f}</td>
                        <td>{old_promotion_gmv/10:.1f}万元</td>
                    </tr>
                </tbody>
            </table>
            <div class="insight-box">
                <h3>用户洞察</h3>
                <p>老客是大促期的主要贡献者，GMV占比达94.5%，ROI（7.35）高于新客（6.01）。老客客单价（306.62元）是新客（152.97元）的2倍。建议重点维护老客，同时通过新客专属优惠提升新客转化。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>6. 秒杀峰值分析</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图6', '')}" alt="秒杀峰值分析">
            </div>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>时段</th>
                        <th>平均订单量</th>
                        <th>平均退款率</th>
                        <th>平均响应时间</th>
                        <th>系统负载</th>
                    </tr>
                </thead>
                <tbody>"""

# 添加秒杀峰值表格行
for time in ['10:00', '12:00', '15:00', '20:00', '22:00']:
    html_content += f"""
                    <tr>
                        <td class="highlight">{time}</td>
                        <td>{avg_orders_by_time[time]:,.0f}</td>
                        <td>{avg_refund_by_time[time]:.2f}%</td>
                        <td>{avg_response_by_time[time]:.0f}ms</td>
                        <td>{avg_load_by_time[time]:.1f}%</td>
                    </tr>"""

html_content += """
                </tbody>
            </table>
            <div class="insight-box">
                <h3>时段分析</h3>
                <p>10:00和20:00为订单高峰期，系统负载接近90%，需提前做好容量规划。22:00为低谷期，可安排系统维护。响应时间在可接受范围内，但高峰期建议增加服务器资源。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>7. 大促后回落分析</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图7', '')}" alt="活动后回落分析">
            </div>
            <div class="insight-box">
                <h3>回落预警</h3>
                <p>大促后各项指标均出现明显回落：UV下降{abs(uv_decline):.1f}%，GMV下降{abs(gmv_decline):.1f}%，转化率下降{abs(conversion_decline):.1f}%。建议在大促后持续1-2周的优惠活动，平滑过渡期，避免用户流失。</p>
            </div>
        </div>
        
        <div class="section">
            <h2>8. 综合数据看板</h2>
            <div class="chart-container">
                <img src="data:image/png;base64,{images.get('图8', '')}" alt="综合数据看板">
            </div>
        </div>
        
        <div class="section">
            <h2>9. 运营优化建议</h2>
            <ul class="recommendation-list">
                <li>
                    <strong>1. 优化优惠策略组合</strong>
                    <p>建议将高门槛满减券（满500减100）与限时折扣组合使用，既保证客单价又提升转化率。针对新客可设置专属无门槛券，提升首次购买率。</p>
                </li>
                <li>
                    <strong>2. 加强用户路径优化</strong>
                    <p>详情页到加购环节转化率仍有提升空间，建议增加加购引导、限时优惠提醒、库存紧张提示等元素，刺激用户决策。</p>
                </li>
                <li>
                    <strong>3. 精细化老客运营</strong>
                    <p>老客贡献了94.5%的GMV，建议建立老客专属权益体系，如会员日、积分兑换、生日礼遇等，提升老客忠诚度和复购率。</p>
                </li>
                <li>
                    <strong>4. 提升系统承载能力</strong>
                    <p>10:00和20:00高峰期系统负载接近90%，建议提前扩容服务器资源，优化数据库查询，引入CDN加速，确保用户体验。</p>
                </li>
                <li>
                    <strong>5. 延长大促活动周期</strong>
                    <p>大促后指标回落明显，建议将大促活动延长至2-3周，通过阶段性优惠维持用户活跃度，平滑过渡期。</p>
                </li>
                <li>
                    <strong>6. 建立数据监控体系</strong>
                    <p>建立实时数据监控看板，重点关注UV、转化率、客单价、系统负载等核心指标，及时发现问题并快速响应。</p>
                </li>
            </ul>
        </div>
        
        <div class="footer">
            <p>报告生成时间：{datetime.now().strftime('%Y年%m月%d日 %H:%M:%S')}</p>
            <p>电商平台数据分析系统 | 321周年庆大促复盘</p>
        </div>
    </div>
</body>
</html>
"""

# 保存HTML文件
with open('电商大促复盘分析报告.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("HTML报告生成成功！")
