import numpy as np
import pandas as pd
from datetime import datetime, timedelta

# 设置随机种子保证数据可复现
np.random.seed(42)

# 生成日期范围
date_ranges = {
    '日常期': pd.date_range('2026-02-01', '2026-02-28'),
    '大促期': pd.date_range('2026-03-01', '2026-03-10'),
    '大促后观察期': pd.date_range('2026-03-11', '2026-03-15')
}

# 合并所有日期
alldates = []
for period, dates in date_ranges.items():
    for date in dates:
        alldates.append(date)

alldates = sorted(alldates)

# 数据集1：每日流量数据（df_traffic）
def generate_traffic_data():
    data = []
    for date in alldates:
        is_promotion = 1 if date in date_ranges['大促期'] else 0
        promotion_day = date_ranges['大促期'].get_loc(date) + 1 if is_promotion else 0
        
        # 确定大促阶段
        if not is_promotion:
            promotion_stage = '日常'
        elif promotion_day <= 2:
            promotion_stage = '预热期'
        elif promotion_day <= 5:
            promotion_stage = '爆发期'
        elif promotion_day <= 7:
            promotion_stage = '高潮期'
        else:
            promotion_stage = '尾声期'
        
        # 计算UV
        weekday = date.weekday()
        base_uv = 25000
        
        # 周末折扣
        if weekday in [5, 6]:
            base_uv *= 0.85
        
        # 大促期间倍数
        if is_promotion:
            if promotion_stage == '预热期':
                base_uv *= 1.8
            elif promotion_stage == '爆发期':
                base_uv *= 3.2
            elif promotion_stage == '高潮期':
                base_uv *= 4.5
            else:  # 尾声期
                base_uv *= 2.5
        
        # 随机波动正负10%
        uv = int(base_uv * (1 + np.random.uniform(-0.1, 0.1)))
        
        data.append({
            '日期': date,
            '是否大促': is_promotion,
            '大促天数': promotion_day,
            '大促阶段': promotion_stage,
            '星期': weekday + 1,  # 1-7表示周一到周日
            'UV': uv
        })
    
    return pd.DataFrame(data)

# 数据集2：用户路径漏斗数据（df_funnel）
def generate_funnel_data():
    data = []
    for date in alldates:
        is_promotion = 1 if date in date_ranges['大促期'] else 0
        
        # 确定大促阶段
        if is_promotion:
            promotion_day = date_ranges['大促期'].get_loc(date) + 1
            if promotion_day <= 2:
                promotion_stage = '预热期'
            elif promotion_day <= 5:
                promotion_stage = '爆发期'
            elif promotion_day <= 7:
                promotion_stage = '高潮期'
            else:
                promotion_stage = '尾声期'
        else:
            promotion_stage = '日常'
        
        # 生成UV（使用数据集1的逻辑）
        weekday = date.weekday()
        base_uv = 25000
        if weekday in [5, 6]:
            base_uv *= 0.85
        if is_promotion:
            if promotion_stage == '预热期':
                base_uv *= 1.8
            elif promotion_stage == '爆发期':
                base_uv *= 3.2
            elif promotion_stage == '高潮期':
                base_uv *= 4.5
            else:  # 尾声期
                base_uv *= 2.5
        uv = int(base_uv * (1 + np.random.uniform(-0.1, 0.1)))
        
        # 各环节转化率
        view_rate = np.random.uniform(0.45, 0.55)
        cart_rate = np.random.uniform(0.25, 0.35)
        
        if is_promotion:
            order_rate = np.random.uniform(0.3, 0.45)
            pay_rate = np.random.uniform(0.65, 0.78)
        else:
            order_rate = np.random.uniform(0.15, 0.25)
            pay_rate = np.random.uniform(0.6, 0.7)
        
        # 计算各环节数值
        view_product = int(uv * view_rate)
        add_cart = int(view_product * cart_rate)
        submit_order = int(add_cart * order_rate)
        complete_pay = int(submit_order * pay_rate)
        
        data.append({
            '日期': date,
            '是否大促': is_promotion,
            '大促阶段': promotion_stage,
            'UV': uv,
            '浏览商品详情': view_product,
            '加入购物车': add_cart,
            '提交订单': submit_order,
            '完成支付': complete_pay
        })
    
    return pd.DataFrame(data)

# 数据集3：优惠策略数据（df_promo）
def generate_promo_data():
    data = []
    promo_types = ['满200减30', '满300减50', '满500减100', '限时折扣', '无门槛券5元', '无门槛券10元']
    
    for date in alldates:
        is_promotion = 1 if date in date_ranges['大促期'] else 0
        promotion_day = date_ranges['大促期'].get_loc(date) + 1 if is_promotion else 0
        
        # 确定大促阶段
        if not is_promotion:
            promotion_stage = '日常'
        elif promotion_day <= 2:
            promotion_stage = '预热期'
        elif promotion_day <= 5:
            promotion_stage = '爆发期'
        elif promotion_day <= 7:
            promotion_stage = '高潮期'
        else:
            promotion_stage = '尾声期'
        
        # 为每种优惠类型生成数据
        for promo_type in promo_types:
            # 发放量（大促期更多）
            if is_promotion:
               发放量 = np.random.randint(5000, 15000)
            else:
               发放量 = np.random.randint(1000, 5000)
            
            # 核销率
            if promo_type == '限时折扣':
                核销率 = np.random.uniform(0.8, 0.95)
            elif promo_type == '满500减100':
                核销率 = np.random.uniform(0.35, 0.5)
            elif promo_type == '满300减50':
                核销率 = np.random.uniform(0.5, 0.65)
            elif promo_type == '满200减30':
                核销率 = np.random.uniform(0.6, 0.75)
            elif promo_type == '无门槛券10元':
                核销率 = np.random.uniform(0.7, 0.85)
            else:  # 无门槛券5元
                核销率 = np.random.uniform(0.75, 0.9)
            
            # 客单价
            if promo_type == '满500减100':
                客单价 = np.random.uniform(500, 800)
            elif promo_type == '满300减50':
                客单价 = np.random.uniform(300, 500)
            elif promo_type == '满200减30':
                客单价 = np.random.uniform(200, 300)
            elif promo_type == '限时折扣':
                客单价 = np.random.uniform(150, 400)
            elif promo_type == '无门槛券10元':
                客单价 = np.random.uniform(100, 250)
            else:  # 无门槛券5元
                客单价 = np.random.uniform(80, 200)
            
            核销量 = int(发放量 * 核销率)
            GMV贡献 = 核销量 * 客单价
            
            data.append({
                '日期': date,
                '大促天数': promotion_day,
                '大促阶段': promotion_stage,
                '优惠类型': promo_type,
                '发放量': 发放量,
                '核销量': 核销量,
                '核销率': round(核销率, 4),
                '客单价': round(客单价, 2),
                'GMV贡献': round(GMV贡献, 2)
            })
    
    return pd.DataFrame(data)

# 数据集4：用户分层数据（df_user）
def generate_user_data():
    data = []
    user_types = ['新客', '老客']
    
    for date in alldates:
        is_promotion = 1 if date in date_ranges['大促期'] else 0
        
        for user_type in user_types:
            # 生成UV
            if is_promotion:
                if user_type == '新客':
                    uv = np.random.randint(8000, 18000)
                else:  # 老客
                    uv = np.random.randint(40000, 70000)
            else:
                if user_type == '新客':
                    uv = np.random.randint(3000, 8000)
                else:  # 老客
                    uv = np.random.randint(15000, 25000)
            
            # 转化率
            if is_promotion:
                if user_type == '新客':
                    conversion_rate = np.random.uniform(0.035, 0.06)
                else:  # 老客
                    conversion_rate = np.random.uniform(0.08, 0.14)
            else:
                if user_type == '新客':
                    conversion_rate = np.random.uniform(0.01, 0.03)
                else:  # 老客
                    conversion_rate = np.random.uniform(0.05, 0.1)
            
            # 客单价
            if is_promotion:
                if user_type == '新客':
                    avg_order_value = np.random.uniform(100, 200)
                else:  # 老客
                    avg_order_value = np.random.uniform(200, 400)
            else:
                if user_type == '新客':
                    avg_order_value = np.random.uniform(80, 150)
                else:  # 老客
                    avg_order_value = np.random.uniform(150, 300)
            
            # 退款率
            if is_promotion:
                if user_type == '新客':
                    refund_rate = np.random.uniform(0.03, 0.06)
                else:  # 老客
                    refund_rate = np.random.uniform(0.02, 0.04)
            else:
                if user_type == '新客':
                    refund_rate = np.random.uniform(0.02, 0.05)
                else:  # 老客
                    refund_rate = np.random.uniform(0.01, 0.03)
            
            # 计算其他指标
            order_users = int(uv * conversion_rate)
            gmv = order_users * avg_order_value
            refund_orders = int(order_users * refund_rate)
            actual_gmv = gmv * (1 - refund_rate)
            
            # 营销成本（大促期更高）
            if is_promotion:
                marketing_cost = np.random.uniform(0.1, 0.2) * gmv
            else:
                marketing_cost = np.random.uniform(0.05, 0.1) * gmv
            
            # ROI
            roi = actual_gmv / marketing_cost if marketing_cost > 0 else 0
            
            data.append({
                '日期': date,
                '是否大促': is_promotion,
                '用户类型': user_type,
                'UV': uv,
                '下单用户数': order_users,
                '转化率': round(conversion_rate, 4),
                '客单价': round(avg_order_value, 2),
                'GMV': round(gmv, 2),
                '退款订单数': refund_orders,
                '退款率': round(refund_rate, 4),
                '实际GMV': round(actual_gmv, 2),
                '营销成本': round(marketing_cost, 2),
                'ROI': round(roi, 2)
            })
    
    return pd.DataFrame(data)

# 数据集5：秒杀峰值数据（df_seckill）
def generate_seckill_data():
    data = []
    time_slots = ['10:00', '12:00', '15:00', '20:00', '22:00']
    
    for date in date_ranges['大促期']:  # 只在大促期生成
        promotion_day = date_ranges['大促期'].get_loc(date) + 1
        
        for slot in time_slots:
            # 订单量
            if slot in ['10:00', '20:00']:  # 高峰
                orders = np.random.randint(3000, 8000)
            elif slot in ['12:00', '15:00']:  # 次高峰
                orders = np.random.randint(1500, 4000)
            else:  # 22:00 低谷
                orders = np.random.randint(1000, 2500)
            
            # 退款订单（退款率约3-8%）
            refund_rate = np.random.uniform(0.03, 0.08)
            refund_orders = int(orders * refund_rate)
            
            # 平均响应时间（ms）
            avg_response_time = np.random.uniform(50, 200)
            
            # 系统负载（%）
            if slot in ['10:00', '20:00']:  # 高峰
                system_load = np.random.uniform(60, 92)
            elif slot in ['12:00', '15:00']:  # 次高峰
                system_load = np.random.uniform(40, 70)
            else:  # 22:00 低谷
                system_load = np.random.uniform(20, 50)
            
            data.append({
                '日期': date,
                '大促天数': promotion_day,
                '时段': slot,
                '订单量': orders,
                '退款订单': refund_orders,
                '退款率': round(refund_rate, 4),
                '平均响应时间(ms)': round(avg_response_time, 2),
                '系统负载(%)': round(system_load, 2)
            })
    
    return pd.DataFrame(data)

# 生成所有数据集
df_traffic = generate_traffic_data()
df_funnel = generate_funnel_data()
df_promo = generate_promo_data()
df_user = generate_user_data()
df_seckill = generate_seckill_data()

# 打印每个数据集的形状和前3行
print("数据集1：每日流量数据")
print(f"形状: {df_traffic.shape}")
print(df_traffic.head(3))
print()

print("数据集2：用户路径漏斗数据")
print(f"形状: {df_funnel.shape}")
print(df_funnel.head(3))
print()

print("数据集3：优惠策略数据")
print(f"形状: {df_promo.shape}")
print(df_promo.head(3))
print()

print("数据集4：用户分层数据")
print(f"形状: {df_user.shape}")
print(df_user.head(3))
print()

print("数据集5：秒杀峰值数据")
print(f"形状: {df_seckill.shape}")
print(df_seckill.head(3))
print()

# 保存到data_cache.pkl
cache_data = {
    'df_traffic': df_traffic,
    'df_funnel': df_funnel,
    'df_promo': df_promo,
    'df_user': df_user,
    'df_seckill': df_seckill
}

pd.to_pickle(cache_data, 'data_cache.pkl')
print("数据已保存到data_cache.pkl")
