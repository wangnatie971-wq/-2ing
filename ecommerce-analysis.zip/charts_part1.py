import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import matplotlib.font_manager as fm

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 读取数据
cache_data = pd.read_pickle('data_cache.pkl')
df_traffic = cache_data['df_traffic']
df_funnel = cache_data['df_funnel']
df_promo = cache_data['df_promo']
df_user = cache_data['df_user']
df_seckill = cache_data['df_seckill']

# 处理日期字段
df_traffic['日期'] = pd.to_datetime(df_traffic['日期'])
df_funnel['日期'] = pd.to_datetime(df_funnel['日期'])
df_promo['日期'] = pd.to_datetime(df_promo['日期'])
df_user['日期'] = pd.to_datetime(df_user['日期'])
df_seckill['日期'] = pd.to_datetime(df_seckill['日期'])

# 图1：01_大促阶段流量与GMV.png
print("正在生成图1：01_大促阶段流量与GMV.png")
fig, ax1 = plt.subplots(figsize=(14, 7))

# 筛选大促期数据
promotion_data = df_traffic[df_traffic['是否大促'] == 1].copy()

# 阶段颜色映射
stage_colors = {
    '预热期': '#f39c12',
    '爆发期': '#e74c3c', 
    '高潮期': '#9b59b6',
    '尾声期': '#3498db'
}

# 准备UV柱状图数据
x = range(len(promotion_data))
colors = [stage_colors[stage] for stage in promotion_data['大促阶段']]
bars = ax1.bar(x, promotion_data['UV'], color=colors, alpha=0.7, label='UV')

# 在柱状图上方标注阶段名称
current_stage = None
for i, (idx, row) in enumerate(promotion_data.iterrows()):
    stage = row['大促阶段']
    if stage != current_stage:
        ax1.text(i, row['UV'] * 1.05, stage, ha='center', fontsize=10, fontweight='bold')
        current_stage = stage

# 设置左Y轴
ax1.set_xlabel('大促天数', fontsize=12)
ax1.set_ylabel('UV', fontsize=12, color='#2c3e50')
ax1.tick_params(axis='y', labelcolor='#2c3e50')
ax1.set_xticks(x)
ax1.set_xticklabels([f"第{day}天" for day in promotion_data['大促天数']], rotation=45)

# 创建右Y轴
ax2 = ax1.twinx()

# 准备GMV数据
daily_gmv = df_user[df_user['是否大促'] == 1].groupby('日期')['GMV'].sum()
daily_actual_gmv = df_user[df_user['是否大促'] == 1].groupby('日期')['实际GMV'].sum()

# 绘制GMV折线
line1 = ax2.plot(x, daily_gmv.values, color='#27ae60', linewidth=2, marker='o', label='GMV')
line2 = ax2.plot(x, daily_actual_gmv.values, color='#27ae60', linewidth=2, linestyle='--', marker='s', label='实际GMV')

# 设置右Y轴
ax2.set_ylabel('GMV (元)', fontsize=12, color='#27ae60')
ax2.tick_params(axis='y', labelcolor='#27ae60')

# 添加图例
lines1, labels1 = ax1.get_legend_handles_labels()
lines2, labels2 = ax2.get_legend_handles_labels()
ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left')

plt.title('大促阶段流量与GMV趋势', fontsize=16, fontweight='bold', pad=20)
plt.tight_layout()
plt.savefig('01_大促阶段流量与GMV.png', dpi=150, bbox_inches='tight')
plt.close()

print("图1生成完成！")

# 图2：02_GMV拆解对比.png
print("正在生成图2：02_GMV拆解对比.png")
fig, axes = plt.subplots(1, 3, figsize=(18, 6))

# 计算大促期和日常期指标
funnel_promotion = df_funnel[df_funnel['是否大促'] == 1]
funnel_daily = df_funnel[df_funnel['是否大促'] == 0]
user_promotion = df_user[df_user['是否大促'] == 1]
user_daily = df_user[df_user['是否大促'] == 0]

# 计算各项指标
promotion_avg_uv = funnel_promotion['UV'].mean()
daily_avg_uv = funnel_daily['UV'].mean()

promotion_conversion = (funnel_promotion['完成支付'].sum() / funnel_promotion['UV'].sum()) * 100
daily_conversion = (funnel_daily['完成支付'].sum() / funnel_daily['UV'].sum()) * 100

promotion_aov = user_promotion['客单价'].mean()
daily_aov = user_daily['客单价'].mean()

# 计算倍数
uv_multiplier = promotion_avg_uv / daily_avg_uv
conversion_multiplier = promotion_conversion / daily_conversion
aov_multiplier = promotion_aov / daily_aov

# 子图1：日均UV对比
x1 = np.arange(2)
bars1 = axes[0].bar(x1, [daily_avg_uv, promotion_avg_uv], color=['#95a5a6', '#e74c3c'], alpha=0.8, width=0.6)
axes[0].set_ylabel('日均UV', fontsize=12)
axes[0].set_xticks(x1)
axes[0].set_xticklabels(['日常期', '大促期'], fontsize=11)
axes[0].set_title(f'日均UV对比\n(提升{uv_multiplier:.2f}倍)', fontsize=13, fontweight='bold')
for bar in bars1:
    height = bar.get_height()
    axes[0].text(bar.get_x() + bar.get_width()/2., height,
                f'{height:,.0f}', ha='center', va='bottom', fontsize=10)

# 子图2：转化率对比
bars2 = axes[1].bar(x1, [daily_conversion, promotion_conversion], color=['#95a5a6', '#e74c3c'], alpha=0.8, width=0.6)
axes[1].set_ylabel('转化率 (%)', fontsize=12)
axes[1].set_xticks(x1)
axes[1].set_xticklabels(['日常期', '大促期'], fontsize=11)
axes[1].set_title(f'转化率对比\n(提升{conversion_multiplier:.2f}倍)', fontsize=13, fontweight='bold')
for bar in bars2:
    height = bar.get_height()
    axes[1].text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}%', ha='center', va='bottom', fontsize=10)

# 子图3：客单价对比
bars3 = axes[2].bar(x1, [daily_aov, promotion_aov], color=['#95a5a6', '#e74c3c'], alpha=0.8, width=0.6)
axes[2].set_ylabel('客单价 (元)', fontsize=12)
axes[2].set_xticks(x1)
axes[2].set_xticklabels(['日常期', '大促期'], fontsize=11)
axes[2].set_title(f'客单价对比\n(提升{aov_multiplier:.2f}倍)', fontsize=13, fontweight='bold')
for bar in bars3:
    height = bar.get_height()
    axes[2].text(bar.get_x() + bar.get_width()/2., height,
                f'{height:.2f}', ha='center', va='bottom', fontsize=10)

plt.suptitle('GMV拆解对比分析', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('02_GMV拆解对比.png', dpi=150, bbox_inches='tight')
plt.close()

print("图2生成完成！")

# 图3：03_用户路径漏斗.png
print("正在生成图3：03_用户路径漏斗.png")
fig, ax = plt.subplots(figsize=(14, 10))

# 计算大促期和日常期漏斗数据
funnel_steps = ['UV', '浏览商品详情', '加入购物车', '提交订单', '完成支付']
step_labels = ['UV', '浏览详情', '加入购物车', '提交订单', '完成支付']

# 大促期数据
promotion_funnel = [funnel_promotion[step].sum() for step in funnel_steps]
# 计算各步骤转化率
promotion_rates = []
for i in range(1, len(promotion_funnel)):
    rate = (promotion_funnel[i] / promotion_funnel[i-1]) * 100
    promotion_rates.append(f'{rate:.1f}%')
promotion_rates.insert(0, '100%')

# 日常期数据
daily_funnel = [funnel_daily[step].sum() for step in funnel_steps]
# 计算各步骤转化率
daily_rates = []
for i in range(1, len(daily_funnel)):
    rate = (daily_funnel[i] / daily_funnel[i-1]) * 100
    daily_rates.append(f'{rate:.1f}%')
daily_rates.insert(0, '100%')

# 颜色设置
promotion_colors = ['#e74c3c', '#e67e22', '#f39c12', '#d35400', '#c0392b']
daily_colors = ['#3498db', '#2980b9', '#5dade2', '#1a5276', '#154360']

# 绘制大促期漏斗（上半部分）
y_positions = range(len(funnel_steps) * 2 - 1, len(funnel_steps) - 1, -1)
for i, (value, rate, color) in enumerate(zip(promotion_funnel, promotion_rates, promotion_colors)):
    y_pos = y_positions[i]
    ax.barh(y_pos, value, color=color, alpha=0.8, height=0.8)
    ax.text(value * 1.02, y_pos, f'{value:,.0f}', va='center', fontsize=11, fontweight='bold')
    ax.text(value * 1.35, y_pos, f'转化率: {rate}', va='center', fontsize=10, color='#7f8c8d')

# 绘制日常期漏斗（下半部分）
y_positions_daily = range(len(funnel_steps) - 1, -1, -1)
for i, (value, rate, color) in enumerate(zip(daily_funnel, daily_rates, daily_colors)):
    y_pos = y_positions_daily[i]
    ax.barh(y_pos, value, color=color, alpha=0.8, height=0.8)
    ax.text(value * 1.02, y_pos, f'{value:,.0f}', va='center', fontsize=11, fontweight='bold')
    ax.text(value * 1.35, y_pos, f'转化率: {rate}', va='center', fontsize=10, color='#7f8c8d')

# 设置Y轴标签
y_labels = []
for i in range(len(funnel_steps) - 1, -1, -1):
    y_labels.append(f'大促期 - {step_labels[i]}')
for i in range(len(funnel_steps)):
    y_labels.append(f'日常期 - {step_labels[i]}')

ax.set_yticks(range(len(funnel_steps) * 2))
ax.set_yticklabels(y_labels, fontsize=11)

# 添加阶段分隔线
ax.axhline(y=len(funnel_steps) - 0.5, color='black', linestyle='--', linewidth=1.5)
ax.text(max(promotion_funnel) * 0.5, len(funnel_steps) - 0.3, '大促期', ha='center', fontsize=14, fontweight='bold', color='#e74c3c')
ax.text(max(promotion_funnel) * 0.5, -0.3, '日常期', ha='center', fontsize=14, fontweight='bold', color='#3498db')

ax.set_xlabel('用户数量', fontsize=12)
ax.set_title('用户路径漏斗对比分析', fontsize=16, fontweight='bold', pad=20)

# 添加图例
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#e74c3c', alpha=0.8, label='大促期'),
    Patch(facecolor='#3498db', alpha=0.8, label='日常期')
]
ax.legend(handles=legend_elements, loc='upper right', fontsize=11)

plt.tight_layout()
plt.savefig('03_用户路径漏斗.png', dpi=150, bbox_inches='tight')
plt.close()

print("图3生成完成！")

# 图4：04_优惠策略对比.png
print("正在生成图4：04_优惠策略对比.png")
fig, axes = plt.subplots(2, 2, figsize=(16, 12))

# 优惠类型颜色映射
promo_colors = {
    '满200减30': '#e74c3c',
    '满300减50': '#e67e22',
    '满500减100': '#f39c12',
    '限时折扣': '#9b59b6',
    '无门槛券5元': '#3498db',
    '无门槛券10元': '#1abc9c'
}

# 准备优惠策略数据
promo_summary = df_promo.groupby('优惠类型').agg({
    '发放量': 'sum',
    '核销量': 'sum',
    '客单价': 'mean',
    'GMV贡献': 'sum'
}).reset_index()

promo_summary['核销率'] = (promo_summary['核销量'] / promo_summary['发放量'] * 100)

# 按核销率排序用于核销率图
promo_by_rate = promo_summary.sort_values('核销率', ascending=True)
# 按GMV排序用于GMV图
promo_by_gmv = promo_summary.sort_values('GMV贡献', ascending=True)
# 按客单价排序用于客单价图
promo_by_aov = promo_summary.sort_values('客单价', ascending=True)

# 子图1：核销率柱状图（左上）
x1 = range(len(promo_by_rate))
colors1 = [promo_colors[promo] for promo in promo_by_rate['优惠类型']]
bars1 = axes[0, 0].barh(x1, promo_by_rate['核销率'], color=colors1, alpha=0.8)
axes[0, 0].set_yticks(x1)
axes[0, 0].set_yticklabels(promo_by_rate['优惠类型'], fontsize=10)
axes[0, 0].set_xlabel('核销率 (%)', fontsize=12)
axes[0, 0].set_title('各优惠类型核销率对比', fontsize=13, fontweight='bold')
for bar, rate in zip(bars1, promo_by_rate['核销率']):
    axes[0, 0].text(rate, bar.get_y() + bar.get_height()/2, 
                    f'{rate:.1f}%', va='center', ha='left', fontsize=9)

# 子图2：GMV贡献柱状图（右上）
x2 = range(len(promo_by_gmv))
colors2 = [promo_colors[promo] for promo in promo_by_gmv['优惠类型']]
bars2 = axes[0, 1].barh(x2, promo_by_gmv['GMV贡献'], color=colors2, alpha=0.8)
axes[0, 1].set_yticks(x2)
axes[0, 1].set_yticklabels(promo_by_gmv['优惠类型'], fontsize=10)
axes[0, 1].set_xlabel('GMV贡献 (元)', fontsize=12)
axes[0, 1].set_title('各优惠类型GMV贡献对比', fontsize=13, fontweight='bold')
for bar, gmv in zip(bars2, promo_by_gmv['GMV贡献']):
    axes[0, 1].text(gmv, bar.get_y() + bar.get_height()/2, 
                    f'{gmv/10000:.1f}万', va='center', ha='left', fontsize=9)

# 子图3：客单价柱状图（左下）
x3 = range(len(promo_by_aov))
colors3 = [promo_colors[promo] for promo in promo_by_aov['优惠类型']]
bars3 = axes[1, 0].barh(x3, promo_by_aov['客单价'], color=colors3, alpha=0.8)
axes[1, 0].set_yticks(x3)
axes[1, 0].set_yticklabels(promo_by_aov['优惠类型'], fontsize=10)
axes[1, 0].set_xlabel('客单价 (元)', fontsize=12)
axes[1, 0].set_title('各优惠类型客单价对比', fontsize=13, fontweight='bold')
for bar, aov in zip(bars3, promo_by_aov['客单价']):
    axes[1, 0].text(aov, bar.get_y() + bar.get_height()/2, 
                    f'{aov:.1f}', va='center', ha='left', fontsize=9)

# 子图4：分阶段核销率趋势折线图（右下）
stages = ['日常', '预热期', '爆发期', '高潮期', '尾声期']
stage_order = {'日常': 0, '预热期': 1, '爆发期': 2, '高潮期': 3, '尾声期': 4}

# 准备分阶段核销率数据
stage_rate_data = {}
for promo in promo_colors.keys():
    promo_data = df_promo[df_promo['优惠类型'] == promo]
    stage_rates = []
    for stage in stages:
        if stage == '日常':
            stage_df = promo_data[promo_data['大促阶段'] == '日常']
        else:
            stage_df = promo_data[promo_data['大促阶段'] == stage]
        if len(stage_df) > 0:
            rate = (stage_df['核销量'].sum() / stage_df['发放量'].sum()) * 100
        else:
            rate = 0
        stage_rates.append(rate)
    stage_rate_data[promo] = stage_rates

# 绘制折线图
x4 = range(len(stages))
for promo, rates in stage_rate_data.items():
    axes[1, 1].plot(x4, rates, color=promo_colors[promo], marker='o', linewidth=2, label=promo)

axes[1, 1].set_xticks(x4)
axes[1, 1].set_xticklabels(stages, fontsize=10)
axes[1, 1].set_ylabel('核销率 (%)', fontsize=12)
axes[1, 1].set_title('分阶段核销率趋势', fontsize=13, fontweight='bold')
axes[1, 1].legend(loc='upper left', fontsize=9)
axes[1, 1].grid(True, alpha=0.3)

plt.suptitle('优惠策略综合对比分析', fontsize=16, fontweight='bold', y=1.02)
plt.tight_layout()
plt.savefig('04_优惠策略对比.png', dpi=150, bbox_inches='tight')
plt.close()

print("图4生成完成！")
print("\n所有图表生成完成！")
