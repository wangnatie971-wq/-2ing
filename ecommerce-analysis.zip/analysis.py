import numpy as np
import pandas as pd

# 读取数据
cache_data = pd.read_pickle('data_cache.pkl')
df_traffic = cache_data['df_traffic']
df_funnel = cache_data['df_funnel']
df_promo = cache_data['df_promo']
df_user = cache_data['df_user']
df_seckill = cache_data['df_seckill']

# 处理日期字段
df_traffic['日期'] = pd.to_datetime(df_traffic['日期'])
df_funnel['日期'] = pd.to_datetime(df_funnel['日期'])
df_promo['日期'] = pd.to_datetime(df_promo['日期'])
df_user['日期'] = pd.to_datetime(df_user['日期'])
df_seckill['日期'] = pd.to_datetime(df_seckill['日期'])

print("=" * 80)
print("1. 大促 vs 日常 核心指标对比")
print("=" * 80)

# 筛选大促期和日常期数据
funnel_promotion = df_funnel[df_funnel['是否大促'] == 1]
funnel_daily = df_funnel[df_funnel['是否大促'] == 0]

user_promotion = df_user[df_user['是否大促'] == 1]
user_daily = df_user[df_user['是否大促'] == 0]

# 计算核心指标
def calculate_metrics(funnel_df, user_df):
    days = len(funnel_df)
    total_uv = funnel_df['UV'].sum()
    avg_uv = funnel_df['UV'].mean()
    total_orders = funnel_df['完成支付'].sum()
    avg_orders = funnel_df['完成支付'].mean()
    conversion_rate = (total_orders / total_uv) * 100
    
    # 计算GMV相关指标
    daily_gmv = user_df.groupby('日期')['GMV'].sum()
    total_gmv = daily_gmv.sum()
    avg_gmv = daily_gmv.mean()
    
    # 计算客单价
    avg_order_value = user_df['客单价'].mean()
    
    avg_refund_rate = user_df['退款率'].mean() * 100
    actual_gmv = user_df['实际GMV'].sum()
    total_marketing_cost = user_df['营销成本'].sum()
    roi = actual_gmv / total_marketing_cost if total_marketing_cost > 0 else 0
    
    return {
        '天数': days,
        '总UV': total_uv,
        '日均UV': avg_uv,
        '总支付订单': total_orders,
        '日均支付订单': avg_orders,
        '整体转化率(%)': conversion_rate,
        '总GMV': total_gmv,
        '日均GMV': avg_gmv,
        '平均客单价': avg_order_value,
        '平均退款率(%)': avg_refund_rate,
        '实际GMV': actual_gmv,
        '总营销成本': total_marketing_cost,
        '整体ROI': roi
    }

promotion_metrics = calculate_metrics(funnel_promotion, user_promotion)
daily_metrics = calculate_metrics(funnel_daily, user_daily)

# 创建对比表
comparison_df = pd.DataFrame({
    '指标': list(promotion_metrics.keys()),
    '大促期': list(promotion_metrics.values()),
    '日常期': list(daily_metrics.values())
})

# 格式化数值
comparison_df['大促期'] = comparison_df['大促期'].apply(lambda x: f"{x:,.2f}" if isinstance(x, (int, float)) else x)
comparison_df['日常期'] = comparison_df['日常期'].apply(lambda x: f"{x:,.2f}" if isinstance(x, (int, float)) else x)

print("\n核心指标对比表：")
print(comparison_df.to_string(index=False))

# 计算关键指标提升倍数
uv_multiplier = promotion_metrics['日均UV'] / daily_metrics['日均UV']
conversion_multiplier = promotion_metrics['整体转化率(%)'] / daily_metrics['整体转化率(%)']
aov_multiplier = promotion_metrics['平均客单价'] / daily_metrics['平均客单价']
gmv_multiplier = promotion_metrics['日均GMV'] / daily_metrics['日均GMV']

print("\n关键指标提升倍数：")
print(f"UV提升倍数: {uv_multiplier:.2f}x")
print(f"转化率提升倍数: {conversion_multiplier:.2f}x")
print(f"客单价提升倍数: {aov_multiplier:.2f}x")
print(f"GMV提升倍数: {gmv_multiplier:.2f}x")

# GMV拆解公式验证
gmv_decomposition = uv_multiplier * conversion_multiplier * aov_multiplier
print(f"\nGMV拆解公式验证：")
print(f"UV倍数 x 转化率倍数 x 客单价倍数 = GMV倍数")
print(f"{uv_multiplier:.2f} x {conversion_multiplier:.2f} x {aov_multiplier:.2f} = {gmv_decomposition:.2f}")
print(f"说明: 由于数据集计算方式不同，拆解公式与实际GMV提升倍数存在差异")
print(f"实际GMV提升倍数: {gmv_multiplier:.2f}x")

print("\n" + "=" * 80)
print("2. 用户路径漏斗各步骤转化率")
print("=" * 80)

def calculate_funnel_rates(funnel_df, period_name):
    total_uv = funnel_df['UV'].sum()
    total_view = funnel_df['浏览商品详情'].sum()
    total_cart = funnel_df['加入购物车'].sum()
    total_order = funnel_df['提交订单'].sum()
    total_pay = funnel_df['完成支付'].sum()
    
    uv_to_view = (total_view / total_uv) * 100
    view_to_cart = (total_cart / total_view) * 100
    cart_to_order = (total_order / total_cart) * 100
    order_to_pay = (total_pay / total_order) * 100
    
    return {
        'UV到详情(%)': uv_to_view,
        '详情到加购(%)': view_to_cart,
        '加购到下单(%)': cart_to_order,
        '下单到支付(%)': order_to_pay
    }

promotion_funnel = calculate_funnel_rates(funnel_promotion, '大促期')
daily_funnel = calculate_funnel_rates(funnel_daily, '日常期')

funnel_comparison = pd.DataFrame({
    '转化步骤': list(promotion_funnel.keys()),
    '大促期': [f"{v:.2f}" for v in promotion_funnel.values()],
    '日常期': [f"{v:.2f}" for v in daily_funnel.values()]
})

print("\n用户路径漏斗转化率对比：")
print(funnel_comparison.to_string(index=False))

print("\n" + "=" * 80)
print("3. 优惠策略汇总")
print("=" * 80)

promo_summary = df_promo.groupby('优惠类型').agg({
    '发放量': 'sum',
    '核销量': 'sum',
    '客单价': 'mean',
    'GMV贡献': 'sum'
}).reset_index()

# 计算核销率
promo_summary['核销率'] = (promo_summary['核销量'] / promo_summary['发放量'] * 100)

# 重命名列
promo_summary.columns = ['优惠类型', '总发放量', '总核销量', '平均客单价', '总GMV', '总核销率(%)']

# 按总GMV降序排列
promo_summary = promo_summary.sort_values('总GMV', ascending=False)

# 格式化数值
promo_summary['总发放量'] = promo_summary['总发放量'].apply(lambda x: f"{x:,}")
promo_summary['总核销量'] = promo_summary['总核销量'].apply(lambda x: f"{x:,}")
promo_summary['平均客单价'] = promo_summary['平均客单价'].apply(lambda x: f"{x:.2f}")
promo_summary['总GMV'] = promo_summary['总GMV'].apply(lambda x: f"{x:,.2f}")
promo_summary['总核销率(%)'] = promo_summary['总核销率(%)'].apply(lambda x: f"{x:.2f}")

print("\n优惠策略汇总（按总GMV降序）：")
print(promo_summary.to_string(index=False))

print("\n" + "=" * 80)
print("4. 新老客大促期分析")
print("=" * 80)

# 筛选大促期数据
user_promotion_analysis = df_user[df_user['是否大促'] == 1]

# 按用户类型分组
user_type_summary = user_promotion_analysis.groupby('用户类型').agg({
    'GMV': 'sum',
    '转化率': 'mean',
    '客单价': 'mean',
    'ROI': 'mean'
}).reset_index()

# 重命名列
user_type_summary.columns = ['用户类型', '总GMV', '平均转化率(%)', '平均客单价', '平均ROI']

# 格式化数值
user_type_summary['总GMV'] = user_type_summary['总GMV'].apply(lambda x: f"{x:,.2f}")
user_type_summary['平均转化率(%)'] = user_type_summary['平均转化率(%)'].apply(lambda x: f"{x:.2f}")
user_type_summary['平均客单价'] = user_type_summary['平均客单价'].apply(lambda x: f"{x:.2f}")
user_type_summary['平均ROI'] = user_type_summary['平均ROI'].apply(lambda x: f"{x:.2f}")

print("\n新老客大促期表现对比：")
print(user_type_summary.to_string(index=False))

print("\n" + "=" * 80)
print("分析完成！")
print("=" * 80)
