import pandas as pd

# 读取数据
cache_data = pd.read_pickle('data_cache.pkl')
df_traffic = cache_data['df_traffic']
df_funnel = cache_data['df_funnel']
df_promo = cache_data['df_promo']
df_user = cache_data['df_user']
df_seckill = cache_data['df_seckill']

# 处理日期字段为字符串格式
df_traffic['日期'] = pd.to_datetime(df_traffic['日期']).dt.strftime('%Y-%m-%d')
df_funnel['日期'] = pd.to_datetime(df_funnel['日期']).dt.strftime('%Y-%m-%d')
df_user['日期'] = pd.to_datetime(df_user['日期']).dt.strftime('%Y-%m-%d')

# 创建优惠策略汇总
promo_summary = df_promo.groupby('优惠类型').agg({
    '发放量': 'sum',
    '核销量': 'sum',
    '客单价': 'mean',
    'GMV贡献': 'sum'
}).reset_index()

promo_summary['核销率'] = (promo_summary['核销量'] / promo_summary['发放量'] * 100)

# 导出为Excel文件
with pd.ExcelWriter('电商大促复盘数据.xlsx', engine='openpyxl') as writer:
    df_traffic.to_excel(writer, sheet_name='流量数据', index=False)
    df_funnel.to_excel(writer, sheet_name='漏斗数据', index=False)
    df_promo.to_excel(writer, sheet_name='优惠策略数据', index=False)
    df_user.to_excel(writer, sheet_name='用户分层数据', index=False)
    df_seckill.to_excel(writer, sheet_name='秒杀峰值数据', index=False)
    promo_summary.to_excel(writer, sheet_name='优惠策略汇总', index=False)

print("Excel导出成功")
